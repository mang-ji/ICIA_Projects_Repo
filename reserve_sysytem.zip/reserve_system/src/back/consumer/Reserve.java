package back.consumer;

import data.consumer.DataAccessObject;

public class Reserve {
	public Reserve() {
		
	}
	
	public String entrance(int serviceCode, String[][] reserveInfo) {
		String menu = null;
		switch(serviceCode) {
		case 4:
			menu = this.setReserve(reserveInfo);
			break;
		default :
			break;
		}
		return menu;
	}
	
	public String setReserve(String[][] reserveInfo) {
		DataAccessObject dao = new DataAccessObject();
		return dao.setReserve(2, reserveInfo);
	}
}
