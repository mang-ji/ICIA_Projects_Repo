package back.consumer;

import java.text.SimpleDateFormat;
import java.util.Date;

import data.consumer.DataAccessObject;

public class Search {
	public Search() {
		
	}
	
	public String[][] entrance(int serviceCode, String request) {
		String[][] menu = null;
		switch(serviceCode) {
		case 1:
			menu = this.compare(request);
			break;
		case 2:
			menu = this.getDate(request);
			break;
		case 3:
			menu = this.getMenuList(request);
			break;
		default :
			break;
		}
		
		return menu;
	}

	public String[][] compare(String request) {
		DataAccessObject dao = new DataAccessObject();
		String[][] menu = new String[300][7];
		this.getMenu(request, menu, dao);
		this.getStore(menu, dao);
		
		return menu;
	}
	
	public void getMenu(String request, String[][] menu, DataAccessObject dao) {
		dao.getMenu(0, request, menu);
	}
	
	public void getStore(String[][] menu, DataAccessObject dao) {
		dao.getStore(menu);
	}
	
	// 날짜 구하기
	public String[][] getDate(String request) {
		DataAccessObject dao = new DataAccessObject();
		String[] dateList;
		String[][] reserveDate;
		
		Date today = new Date();
		String date = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		for(int i=0; i<7; i++) {
			String compareDate = sdf.format(today);
			if(dao.getDate(request, compareDate)) {
				date = date.equals("")? compareDate: date + "," + compareDate;
			}
			today.setDate(today.getDate()+1);
		}
		// 1.[0] 2012-01-01[1]
		dateList = date.split(",");
		reserveDate = new String[dateList.length][1];
		for(int index=0; index<dateList.length; index++) {
			reserveDate[index][0] = dateList[index];
		}
		
		return reserveDate;
	}
	
	public String[][] getMenuList(String storeCode) {
		DataAccessObject dao = new DataAccessObject();
		String[][] menuList = new String[300][4];
		this.setMenuList(storeCode, menuList, dao);
		this.appendValue(menuList, dao);
		
		return menuList;
	}
	
	public void setMenuList(String storeCode, String[][] menuList, DataAccessObject dao) {
		dao.getMenuList(storeCode, menuList);
	}
	
	public void appendValue(String[][] menuList, DataAccessObject dao) {
		dao.appendValue(menuList);
	}
}
