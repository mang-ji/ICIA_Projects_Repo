package back.consumer;

public class Controller {
	public Controller() {

	}

	public String[][] entrance(int serviceCode, String request) {
		Search search;
		Reserve reserve;
		String[][] menu = null;
		switch(serviceCode) {
		case 1:
			search = new Search();
			menu = search.entrance(serviceCode, request);
			break;
		case 2:
			search = new Search();
			menu = search.entrance(serviceCode, request);
			break;
		case 3:
			search = new Search();
			menu = search.entrance(serviceCode, request);
			break;
		default :
			break;	
		}

		return menu;
	}

	public String entrance(int serviceCode, String[][] request) {
		String menu = null;
		switch(serviceCode)	{
		case 4:
			Reserve reserve = new Reserve();
			menu = reserve.entrance(serviceCode, request);
			break;
		default :
		}
		return menu;
	}
}
