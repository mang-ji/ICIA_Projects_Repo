package front.consumer;

import java.util.Scanner;

import back.consumer.Controller;

public class Client {

	private Scanner scanner;

	public Client() {
		this.scanner = new Scanner(System.in);
		this.controller();
	}

	public void controller() {
		String title, word;
		String[][] menu;
		String[][] reserveDate;
		Controller ctl = new Controller();

		while(true) {
			/* Job1 */
			title = this.setTitle();
			word = this.fJob11(title);
			menu = ctl.entrance(1, word);
			this.fJob13(title, word, menu);

			/* Job2 */
			if(this.userInput("예약하시겠습니까?(y/n) : ").equals("y")) break;
		}
        
		int storeIndex = Integer.parseInt(this.userInput("Store Select : ")) -1;
		reserveDate = ctl.entrance(2, menu[storeIndex][0]);
		this.fStep1(title, menu[storeIndex][1], reserveDate);
		

		int dateIndex = Integer.parseInt(this.userInput("Date Select : ")) - 1;
		String[][] storeMenuList = ctl.entrance(3, menu[storeIndex][0]);

		this.fStep2(title, menu[storeIndex][1], reserveDate[dateIndex][0], storeMenuList);

		String[][] reserveInfo = jStep5(title, menu[storeIndex], reserveDate[dateIndex][0], storeMenuList);
		
		if(this.userInput("위 정보로 예약하시겠습니까(y/n)").equals("y")) {
			// 정상 메시지|오류 메시지 출력
			System.out.println(ctl.entrance(4, reserveInfo));
		}
		
	}

	public String[][] jStep5(String title, String[] storeInfo, String reserveDate, String[][] storeMenuList) {
		String[][] reserveInfo = null;
		StringBuffer info = new StringBuffer();
		while(true) {
			info.append(storeInfo[0] + ",,," + reserveDate);
			info.append("," + storeMenuList[Integer.parseInt(this.userInput("Menu Select : "))-1][1]);
			info.append("," + this.userInput("Quantity : "));
			info.append(",0.0");

			// 1, ,,, 2, 3, 4, :
			// 1 2 3 4 : 1 2 3 4 :
			if(this.userInput("Continue(y/n)?").equals("n")) {
				break;
			} else {
				info.append(":");
			}	
		}
		// 11[0], 예약자[1], 연락처[2], 2021-05-07[3], 치즈피자[4], 1[5], 0.0[6]
		reserveInfo = new String[info.toString().split(":").length][];
		for(int record=0; record<reserveInfo.length; record++) {
			reserveInfo[record] = (info.toString().split(":")[record]).split(",");
		}

		this.display(title);
		this.display("                                       [ Step 3 ]\n");
		this.display("[" + storeInfo[1] + "] " + "예약일자: " + reserveDate + "\n");
		this.display("[ 선택 메뉴 ]\n");
		for(int index=0; index<reserveInfo.length; index++) {
			this.display(" " + (index+1) + "." + reserveInfo[index][4] + ":" + reserveInfo[index][5] + "\n");
		}

		this.display("[ 예약자 정보 ]\n");
		String userName = this.userInput(" 예약자: ");
		String userPhone = this.userInput(" 연락처: ");

		for(int index=0; index<reserveInfo.length; index++) {
			reserveInfo[index][1] = userName;
			reserveInfo[index][2] = userPhone;
		}
		
		this.display(title);
		this.display("                                       [ Step 4 ]\n");
		this.display("[" + storeInfo[1] + "] " + "예약일자: " + reserveDate + "\n");
		this.display("[ 선택 메뉴 ]\n");
		for(int index=0; index<reserveInfo.length; index++) {
			this.display(" " + (index+1) + "." + reserveInfo[index][4] + ":" + reserveInfo[index][5] + "\n");
		}
		this.display("[ 예약자 정보 ]\n");
		this.display(" 예약자: " + userName + "\t연락처:" + userPhone + "\n");
		
		return reserveInfo;
	}

	public void fStep2(String title, String storeName, String date, String[][] storeMenuList) {
		int index = 0;

		this.display(title);
		this.display("                                       [ Step 2 ]\n");
		this.display("[" + storeName + "] " + "예약일자: " + date + "\n");
		this.display("---------------------------------------\n");
		this.display(" 순번    메뉴      가격    평점 \n");
		this.display("---------------------------------------\n");

		// 1 <- 2
		for(String[] record : storeMenuList) {
			index++;
			int colIndex = 0;
			if(record[0] != null) {
				StringBuffer line = new StringBuffer();
				for(String item : record) {
					colIndex++;
					line.append((colIndex ==1)? " "+index+"\t":"");
					line.append((colIndex ==2)? item+"\t":"");
					line.append((colIndex ==3)? item+"\t":"");
					line.append((colIndex ==4)? item+"\n":"");
				}
				this.display(line.toString());
				line.delete(0, line.length());
			}
		}
		this.display("---------------------------------------\n");
	}

	public void fStep1(String title, String store, String[][] reserveDate) {
		int index=0;

		this.display(title);
		this.display("                                       [ Step 1 ]\n");
		this.display("[" + store + "]" + "______\n");
		this.display("-------------------------\n");
		this.display("      예약 가능 날짜      \n");
		this.display("-------------------------\n");
		
		for(String[] info : reserveDate) {
			index++;
			this.display(" " + index + ".\t");
			this.display(info[0] + "\n");
		}
		
	}

	public void fJob13(String title, String word, String[][] menu) {
		// goods <- menu[][]
		String goods;
		this.display(title);
		this.display("[ 검색어 :" + word + " ]\n");
		this.display("----------------------------------------------------------\n");
		this.display("  순번   상호        상품       가격    위치     평점    주문  \n");
		this.display("----------------------------------------------------------\n");
		for(int record=0; record < menu.length; record++) {
			if(menu[record][1] == null) {
				
				break;
			}

			for(int index=0; index<menu[record].length; index++) {
				goods = menu[record][index];
				goods = (index==0)? " " + (record+1): goods;
				this.display(goods);
				this.display((index == menu[record].length-1)? "\n": "\t");
			}
		}
	}

	public String fJob11(String title) {
		this.display(title);
		return this.userInput("비교검색 상품명 :");
	}

	public String setTitle() {
		StringBuffer title = new StringBuffer();
		title.append("************************************************\n");
		title.append("                    예약서비스                     \n");
		title.append("************************************************\n");

		return title.toString();
	}

	public String userInput(String text) {
		this.display(text);
		return scanner.next();
	}

	public void display(String text) {
		System.out.print(text);
	}

	/*
	private boolean isValidate(String value) {
		boolean result;
		try {
			Integer.parseInt(value);
			result = true;
		} catch(Exception e) {
			result = false;
		}

		return result;
	}

	private boolean isRange(int value, int start, int end) {
		boolean result;

		//숫자가 시작값보다 크거나 숫자가 종료값보다 작아야 트루다 아니면 펄스다
		if(value>=start && value<=end) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public boolean isPhone(String phone) {
		boolean result = false;
		
		if(phone.length() == 11 && phone.substring(0, 3).equals("010")) {
			result = true;
		}
		
		return result;
	}
	*/
	
}