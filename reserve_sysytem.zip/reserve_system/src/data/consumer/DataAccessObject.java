package data.consumer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DataAccessObject {
	FileReader reader;
	BufferedReader bReader;
	String[] fileInfo = {"C:\\F\\Data\\Menu.txt",
			"C:\\F\\Data\\Restaurant.txt",
	"C:\\F\\Data\\Order.txt"};

	public DataAccessObject() {

	}

	public String[] fileReading(int index, int roomSize) {
		String[] source = new String[roomSize];
		try {
			reader = new FileReader(this.fileInfo[index]);
			bReader = new BufferedReader(reader);

			int record = 0;
			while((source[record] = bReader.readLine()) != null) {
				record++;
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				bReader.close();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}

		return source;
	}

	public void getMenu(int index, String word, String[][] menu) {
		String[] source = this.fileReading(0, menu.length);
		int menuIndex=-1;
		// 1차원 배열 1[0],생고기김치찌개[1],13000[2] -> 2차원 배열에 적재
		// 순번[0] 상호[1] 상품[2] 가격[3] 위치[4] 평점[5] 주문[6]
		// [0]<-[0] || [2]<-[1] || [3]<-[2]

		for(int record=0; record<source.length; record++) {
			if(source[record] != null) {
				if(source[record].contains(word)) {
					menuIndex++;
					menu[menuIndex][0] = source[record].split(",")[0];
					menu[menuIndex][2] = source[record].split(",")[1];
					menu[menuIndex][3] = source[record].split(",")[2];
				}
			}
		}
	}

	public void getStore(String[][] menu) {
		String[] source = this.fileReading(1, menu.length);
		// 1[0] 명동찌개[1] 강북[2] 010-2339-7312[3]
		// 순번[0] 상호[1] 상품[2] 가격[3] 위치[4] 평점[5] 주문[6]
		// [1]<-[1] || [4]<-[2]

		for(int record=0; record<menu.length; record++) {
			if(menu[record][0] != null) {
				for(int index=0; index<source.length; index++) {
					if(source[index] != null) {
						String[] line = source[index].split(",");
						if(menu[record][0].equals(line[0])) {
							menu[record][1] = line[1];
							menu[record][4] = line[2];
							break;
						}
					}
				}
			}
		}
	}

	public boolean getDate(String storeCode, String date) {
		boolean reservedCheck = true;

		String[] reserved = this.fileReading(2, 300);

		for(String line : reserved) {
			if(line != null) {
				String[] reservedInfo = line.split(",");
				if(reservedInfo[0].equals(storeCode)) {
					if(reservedInfo[2].equals(date)) {
						reservedCheck = false;
					}
				}
			} else {
				break;
			}
		}

		// TODO Auto-generated method stub
		return reservedCheck;
	}

	public void getMenuList(String storeCode, String[][] menuList) {
		String[] list = this.fileReading(0, menuList.length);
		int index = -1;
		for(String item : list) {
			if(item != null) {
				String[] it = item.split(",");
				if(it[0].equals(storeCode)) {
					index++;
					for(int record=0; record<it.length; record++) {
						menuList[index][record] = it[record];
					}
				}
			}
		}
	}

	public void appendValue(String[][] menuList) {
		String[] list = this.fileReading(2, menuList.length);
		int index=-1;
		int count=0;
		double total=0.0;

		for(String[] item : menuList) {
			if(item[0] != null) {
				index++;
				for(String line : list) {
					if(line != null) {
						String[] record = line.split(",");
						if(item[0].equals(record[0])) {
							if(item[1].equals(record[3])) {
								if(!record[5].equals("0.0")) {
									count++;
									total += Double.parseDouble(record[5]);
								}
							}
						}
					} else {
						break;
					}
				}
				menuList[index][3] = (Math.round(total/count)*10/10.0)+"";
				count = 0;
				total = 0;
			}
		}
	}

	public boolean fileWrite(String text, FileWriter writer, BufferedWriter bWriter) {
		boolean result = false;
		try {
			bWriter.write(text);
			bWriter.newLine();
			result = true;
		} catch(IOException e) {
			e.printStackTrace();
		}

		return result;
	}

	public String setReserve(int fileIndex, String[][] reserveInfo) {
		String result="error";
		FileWriter writer = null;
		BufferedWriter bWriter = null;
		try {
			writer = new FileWriter(fileInfo[fileIndex], true);
			bWriter = new BufferedWriter(writer);

			StringBuffer text = new StringBuffer();
			for(int record=0; record<reserveInfo.length; record++) {
				for(int index=0; index<reserveInfo[record].length; index++) {
					if(index != 1) {
						text.append(reserveInfo[record][index]);
						if(index != reserveInfo[record].length-1) {
							text.append(",");
						}
					}
				}
				if(!this.fileWrite(text.toString(), writer, bWriter)) 
				{
					break;
				}
				text.delete(0, text.length());
			}
			result = "success";
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			try {
				bWriter.flush();
				bWriter.close();
			} catch(IOException e) {
				
			}
		}

		return result;
	}
}