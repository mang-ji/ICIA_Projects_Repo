package one.schedule.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class Test1 {
	
	
	
	@Test
	public void test() {
		
		String conInfo = "jdbc:oracle:thin:@106.243.194.229:9999:xe";
		String userId = "KMJ";
		String userPassword = "1234";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection connection = DriverManager.getConnection(conInfo, userId, userPassword);
		    log.info(connection);
		    System.out.println("야호~");
			} catch (SQLException e) {
		
				e.printStackTrace();
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		
		
	}

}
