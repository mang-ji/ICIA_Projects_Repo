/**
 * location.href
   location.protocol
   location.port
   location.pathname
   location.search
 */
let publicIp;
let browser1;

function getBrowser(){
	
	const userAgent=navigator.userAgent.toLowerCase();
	
	let browser;
   

      if(userAgent.indexOf('edg')>-1){
	
	     browser='Edge';

      }else if(userAgent.indexOf('whale')>-1){

	     browser='Whale';

      }else if(userAgent.indexOf('chrome')>-1){

	  browser='Chrome';

      }else if(userAgent.indexOf('firefox')>-1){

	     browser='Firefox';

       }else{
	
	     browser='any';
	
        }

      getB(browser);

      }

function getB(data){
	browser1 = data;
}

function sendAccessInfo (){
	  
	const browser = makeInput("hidden","browser", browser1);
	const uCode = document.getElementsByName("uCode")[0];
	const aCode = document.getElementsByName("aCode")[0];
	const method = makeInput("hidden", "method", 1);
	const pubIp = makeInput("hidden", "publicIp", publicIp);
	const privateIp = makeInput("Access", "privateIp", location.host); 
	
	
	/* 
	  makeInput("hidden","info",나이)
	  makeInput("hidden","info",이름)
	 */
      

  
	let f = makeForm("sendLogIn","post");
	f.appendChild(browser);
	f.appendChild(uCode); 
	f.appendChild(aCode);
	f.appendChild(method);
	f.appendChild(pubIp);
	f.appendChild(privateIp);


	
	document.body.appendChild(f);
	
	f.submit();
}

function makeForm(action, method, name = null){
	let f = document.createElement("form");
	
	if(name !=null){f.setAttribute("name", name);}
	f.setAttribute("action", action);
	f.setAttribute("method", method);
	
	return f;
}

function makeInput(type, name, value){
	let input = document.createElement("input");
	
	input.setAttribute("type" , type);
	input.setAttribute("name" , name);
	input.setAttribute("value" , value);
	
	return input;
	
	
}

function getAjax(jobCode, clientData, fn){
	/* Step1 */
	let ajax = new XMLHttpRequest();
	
	/* Step2 */
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[fn](JSON.parse(ajax.responseText));
		}
		
	};
	/* Step3 */
	if(clientData !=""){
		jobCode += "?" + clientData;
	}
	ajax.open("GET", jobCode);
	/* Step4 */
	ajax.send();
}

function postAjax(jobCode, clientData, fn){
	
	let ajax = new XMLHttpRequest();
	
	ajax.onreadystatechange = function(){
	if(ajax.onreadystatechange == 4 && ajax.status == 200){
		window[fn](JSON.parse(ajax.responseText));
		
	  }
	
   };

       ajax.open("POST", jobCode);
       
       ajax.send(clientData);
}

function setPublicIp(data){
	publicIp = data.ip;
	
}


