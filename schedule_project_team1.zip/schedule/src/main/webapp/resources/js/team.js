let sendTeCode;

function postAjax(jobCode, clientData, fn, type){
   /* Step 1*/
   let ajax = new XMLHttpRequest();
      
   /* Step2 */
   ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
         /* Step 5 */
         
         const jsonData = ajax.responseText;
        // alert(jsonData);
         
         window[fn](JSON.parse(jsonData));
      }
   };
   /* Step 3 */
   ajax.open("POST", jobCode);
   /* Step 4 */

if(type!="json"){
	
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	
}else{
	  ajax.setRequestHeader("Content-type","application/json");
}
    
 
   ajax.send(clientData);
}

function getAjax(jobCode, clientData, fn){
	/* Step1 */
	let ajax = new XMLHttpRequest();
	
	/* Step2 */
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[fn](JSON.parse(ajax.responseText));
		}
		
	};
	/* Step3 */
	if(clientData !=""){
		jobCode += "?" + clientData;
	}
	ajax.open("GET", jobCode);
	/* Step4 */
	ajax.send();
}

function goDash(){
	
	let logo = document.getElementsByName("logo1")[0];
	let f = document.createElement("form");
	
	f.appendChild(logo);
	
	f.action="dashBoard";
	f.method="get";
	
	document.body.appendChild(f);
	
	f.submit();
	
	
}

function backTeam(){
	
	let Tback = document.getElementsByName("Tback")[0];
	let f = document.createElement("form");
	
	f.appendChild(Tback);
	
	f.action="team";
	f.method="get";
	
	document.body.appendChild(f);
	
	f.submit();
	
	
}



function addTeam(){
	
	let addTeamName = prompt('Team Name 을 입력해주세요.');
	let sendJsonData = [];
		sendJsonData.push({teName:addTeamName});
		let clientData = JSON.stringify(sendJsonData);
		postAjax('schedule/addTeam', clientData, 'getTeamList', 'json');
		
		
	alert(clientData);
	
}

function callMemberList(teCode){
		//alert(teCode);
		let sendJsonData = [];
		sendJsonData.push({teCode:teCode});
		let clientData = JSON.stringify(sendJsonData);
		postAjax('schedule/memberList', clientData, 'getMemberList','json');
	
} 


function getMemberList(jsonData){
	sendTeCode = jsonData[0].teCode;
	let memberList = document.getElementById("memberList");
	let memeberText = "";
	let count = 0;
	let mCount = document.getElementById("mCount");

	/*	
		memberList.innerHTML = jsonData[index].mbName + jsonData[index].mbId;
	}
	*/
	
	for(index =0;  index<jsonData.length; index++){
		
	memeberText +=   "<span class= 'memebrLine'>" + jsonData[index].mbName+ '    ' +  jsonData[index].mbId+'  '+ "[ " + jsonData[index].cgName + " ]" +"</span>" + "<br>";
	count++;
	}
	
	memberList.innerHTML = memeberText;
	mCount.innerHTML = '  '+"["+ ' ' +count+ ' '+"]";
}





function sendMail(){
	
	let values = document.getElementsByName("tdetails");
	let tdetails= [];
	let sendJsonData = [];
	
	for(index=0; index<values.length; index++){
		
		if(values[index].checked){
			
			tdetails.push({mbId:values[index].value});
		}
		
	}
	
	 sendJsonData.push({teCode:sendTeCode,tdetails});

		
		let clientData = JSON.stringify(sendJsonData);
		
	alert(clientData);
	
		postAjax('schedule/sendMail', clientData, 'getMemberList', 'json');

}




function memManage(){ //멤버관리
	let addMem = document.getElementById("addMem"); 
	let deleteMem = document.getElementById("deleteMem");

	addMem.style.display= "block";
	deleteMem.style.display= "block";

   

}



function selectMember(uCode){
	
	let memberBox = document.getElementById("memberBox");
	let teamBox = document.getElementById("teamBox");
	let selectMem = document.getElementById("selectMem");
	
	
	memberBox.style.display = "none";
	teamBox.style.display = "none";
	selectMem.style.display = "block";
	
		let sendJsonData = [];
		sendJsonData.push({mbId:uCode, teCode:sendTeCode});
		let clientData = JSON.stringify(sendJsonData);
		postAjax('schedule/frList', clientData, 'getFrList', 'json');
}

function getFrList(jsonData){
	
	let frList = document.getElementById("frList");
	let frText = "";
	let count = 0;
	let fCount = document.getElementById("fCount");

	for(index =0;  index<jsonData.length; index++){
		
	frText +=   "<span class= 'frLine'>"+ "<input type= 'checkBox' name= 'tdetails' value= '"+jsonData[index].mbId+"' />" + jsonData[index].mbId + '    ' +  jsonData[index].mbName+'  '+ "</span>" + "<br>";
	count++;
	}
	
	frList.innerHTML = frText;
	fCount.innerHTML = '  '+"["+ ' ' +count+ ' '+"]";
	
}



 function callTeamList(uCode){
	
		let sendJsonData = [];
		sendJsonData.push({mbId:uCode});
		let clientData = JSON.stringify(sendJsonData);
		postAjax('schedule/teamList', clientData, 'getTeamList', 'json');
		
	}

function getTeamList(jsonData){
	
	
	let data = "";
	let count =0;
	let count1=1;
	let teamCount = document.getElementById("count"); 
	let teamList = document.getElementById("teamList");
	
	for(index=0; index<jsonData.length; index++){
		
		data += "<span onClick = 'callMemberList ("+ jsonData[index].teCode +")'>" + "[" + [count1]+ "]" +'  ' + jsonData[index].teName +"</span>"+"<br>";
		count1++;
	    count++;
	}
	
	
         teamCount.innerHTML = '  '+"["+ ' ' +count+ ' '+"]";
	
	teamList.innerHTML = data;

 }


