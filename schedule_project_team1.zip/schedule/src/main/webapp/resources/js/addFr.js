function postAjax(jobCode, clientData, fn, type){
   /* Step 1*/
   let ajax = new XMLHttpRequest();
      
   /* Step2 */
   ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
         /* Step 5 */
         
         const jsonData = ajax.responseText;
        // alert(jsonData);
         
         window[fn](JSON.parse(jsonData));
      }
   };
   /* Step 3 */
   ajax.open("POST", jobCode);
   /* Step 4 */

if(type!="json"){
	
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	
}else{
	  ajax.setRequestHeader("Content-type","application/json");
}
    
 
   ajax.send(clientData);
}

function getAjax(jobCode, clientData, fn){
	/* Step1 */
	let ajax = new XMLHttpRequest();
	
	/* Step2 */
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[fn](JSON.parse(ajax.responseText));
		}
		
	};
	/* Step3 */
	if(clientData !=""){
		jobCode += "?" + clientData;
	}
	ajax.open("GET", jobCode);
	/* Step4 */
	ajax.send();
}

function noFr(){
	
	let ucode = document.getElementsByName("uCode")[0];
	let values = document.getElementsByName("mbId2")[0];
	
	let sendJsonData = [];

	
	
	
	 sendJsonData.push({mbId:ucode.value, mbId2:values.value}); 

		
		let clientData = JSON.stringify(sendJsonData);
		
	alert(clientData);
	alert("여기!");
	
		postAjax('schedule/clickNo', clientData, 'getFrList', 'json');


	}
	

function yesFr(){
	let ucode = document.getElementsByName("uCode")[0];
	let values = document.getElementsByName("mbId2")[0];
	
	let sendJsonData = [];
		
	
	 sendJsonData.push({mbId:ucode.value, mbId2:values.value}); 

		
		let clientData = JSON.stringify(sendJsonData);
		
	alert(clientData);
	alert("여기!");
	
		postAjax('schedule/clickYes', clientData, 'getFrList', 'json');


	}
	
	function getFrList(){
		
	}
	
	
	