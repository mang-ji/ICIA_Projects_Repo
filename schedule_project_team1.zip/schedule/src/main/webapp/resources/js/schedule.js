let count=0;

function goDash(){
	
	let logo = document.getElementsByName("logo1")[0];
	let f = document.createElement("form");
	
	f.appendChild(logo);
	
	f.action="dashBoard";
	f.method="get";
	
	document.body.appendChild(f);
	
	f.submit();
	
	
}

function newSd(){ //첫번쨰
	
	
	let f = document.createElement("form");
	
	f.action = "goCalendar";
	f.method = "get";
	
	document.body.appendChild(f);
	
	f.submit();
	
	
	/*let addimg = document.getElementById("addimg"); 
	
	addimg.style.display= "block";
	
	let imgList = document.getElementById("imgList");
	let sText = "";
    
	/*	
		memberList.innerHTML = jsonData[index].mbName + jsonData[index].mbId;
	}


		
	sText += "<input type = 'file' name = 'imgFile' required/><button id = 'plusimg' onClick = 'addimg()' >ADD</button><button id = 'remove' onClick = 'deleteimg()' >DELETE</button>";
	
	imgList.innerHTML = sText; 	*/
	
	

}




function addimg(){ //추가
	
	let addimg = document.getElementById("addimg");
	
	
	if(count<4){
		addimg.innerHTML +=  "<div><input type = 'file' name = 'imgFile'/><button id = 'plusimg' onClick = 'addimg()' >ADD</button><button id = 'remove' onClick = 'deleteimg(this)' >DELETE</button></div>";
       
        count++;
	}
	
}

function deleteimg(child){

   let parent = child.parentNode;
   parent.parentNode.removeChild(parent);
   count--;
}

function submitImg(){
	
	let imgFile = document.getElementsByName("imgFile");
	
	let f = document.createElement("form");

   	
	f.action = "addImg";
	f.method = "post";
	f.enctype = "multipart/form-data";
	
	for(i=imgFile.length-1; i>=0; i--){
	f.append(imgFile)[i];	
		
	}
	document.body.appendChild(f);
	
	f.submit();
}




