let publicIp;

let count =0;


	

function logOut(){
	
			var userAgent=navigator.userAgent.toLowerCase();
      let browser1='';

if(userAgent.indexOf('edg')>-1){
	
	browser1='Edge';
}else if(userAgent.indexOf('whale')>-1){

	browser1='Whale';

}else if(userAgent.indexOf('chrome')>-1){

	browser1='Chrome';

}else if(userAgent.indexOf('firefox')>-1){

	browser1='Firefox';

}else{
	browser1='any';
	
}	 


	const browser = makeInput("hidden","browser", browser1);
	const uCode = document.getElementsByName("mbId")[0];
	const method = makeInput("hidden", "method", -1);
	const pubIp = makeInput("hidden","publicIp", publicIp);
	const privateIp = makeInput("Access", "privateIp", location.host); 
	
	
	
	/* 
	  makeInput("hidden","info",나이)
	  makeInput("hidden","info",이름)
	 */
      

  
	let f = makeForm("logOut","post");
	f.appendChild(uCode);
	f.appendChild(method);
	f.appendChild(pubIp);
	f.appendChild(privateIp);
	f.appendChild(browser);


	
	document.body.appendChild(f);
	
	f.submit();	
	
}

function makeForm(action, method, name = null){
	let f = document.createElement("form");
	
	if(name !=null){f.setAttribute("name", name);}
	f.setAttribute("action", action);
	f.setAttribute("method", method);
	
	return f;
}

function makeInput(type, name, value){
	let input = document.createElement("input");
	
	input.setAttribute("type" , type);
	input.setAttribute("name" , name);
	input.setAttribute("value" , value);
	
	return input;
	
	
}

function getAjax(jobCode, clientData, fn){
	/* Step1 */
	let ajax = new XMLHttpRequest();
	
	/* Step2 */
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[fn](JSON.parse(ajax.responseText));
		}
		
	};
	/* Step3 */
	if(clientData !=""){
		jobCode += "?" + clientData;
	}
	ajax.open("GET", jobCode);
	/* Step4 */
	ajax.send();
}

function postAjax(jobCode, clientData, fn, type){
   /* Step 1*/
   let ajax = new XMLHttpRequest();
      
   /* Step2 */
   ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
         /* Step 5 */
         
         const jsonData = ajax.responseText;
        // alert(jsonData);
         
         window[fn](JSON.parse(jsonData));
      }
   };
   /* Step 3 */
   ajax.open("POST", jobCode);
   /* Step 4 */

if(type=="json"){
	ajax.setRequestHeader("Content-type","application/json");
	
	
}else{
	  ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
}
    
 
   ajax.send(clientData);
}


function setPublicIp(data){
	publicIp = data.ip;
	
}


function search(){
	
    let b = document.getElementById("b"); 
	let pop = document.getElementById("pop");

	b.style.display= "block";
	pop.style.display= "block";
	
	

}

function searchFr(){
	
	let word = document.getElementsByName("word")[0];
	
		let sendJsonData = [];
		sendJsonData.push({word:word.value});
		let clientData = JSON.stringify(sendJsonData);
		postAjax('schedule/search', clientData, 'searchResult', 'json');
		
	
	
}

function searchResult(jsonData){
	
 
    alert(JSON.stringify(jsonData));
    
	let frList2 = document.getElementById("frList2");
	let frText = "";
	
	if(jsonData != ""){
	for(index =0;  index<jsonData.length; index++){
		
	frText +=   "<span class= 'frLine'>"+ "<input type= 'checkBox' name= 'userbean' value= '"+jsonData[index].mbId+"'/>" + jsonData[index].mbId + '    ' +  jsonData[index].mail+'  '+  jsonData[index].mbName+'  '+ "</span>" + "<br>";
	
	
	}
	frText += "<div onClick='plusFr()'>친구 추가</div>"
	//fCount.innerHTML = '  '+"["+ ' ' +count+ ' '+"]";
	}else{
		
		frText +=   "<input type = 'text' name = 'friend'/><div onClick = 'inviteFr()'>친구 초대</div>";
		
	}
	
	frList2.innerHTML = frText;

}

function inviteFr(){
		
	let values = document.getElementsByName("friend")[0];

	let sendJsonData = [];
		
	 sendJsonData.push({mail:values.value});

		let clientData = JSON.stringify(sendJsonData);
		
	
	
		postAjax('schedule/sendMail2', clientData, 'addFr', 'json');

	
}

function getFrList(jsonData){
	
	let frList = document.getElementById("frList");
	let frText = "";
	let count = 0;
	let fCount = document.getElementById("fCount");

	for(index =0;  index<jsonData.length; index++){
		
	frText +=   "<span class= 'frLine'>"+ "<input type= 'checkBox' name= 'tdetails' value= '"+jsonData[index].mbId+"' />" + jsonData[index].mbId + '    ' +  jsonData[index].mbName+'  '+ "</span>" + "<br>";
	count++;
	}
	
	frList.innerHTML = frText;
	fCount.innerHTML = '  '+"["+ ' ' +count+ ' '+"]";
	
}


function plusFr(){
	let ucode = document.getElementsByName("mbId")[0];
	let values = document.getElementsByName("userbean");
	let userbean= [];
	let sendJsonData = [];
	
	for(index=0; index<values.length; index++){
		
		if(values[index].checked){
			
			userbean.push({ucode:values[index].value});
		}
		
	}
	
	 sendJsonData.push({mbId:ucode.value,userbean}); 

		
		let clientData = JSON.stringify(sendJsonData);
		
	alert(clientData);
	alert("여기!");
	
		postAjax('schedule/sendAddFr', clientData, 'getFrList', 'json');


	
	
}



function addFr(message){
	
	alert(JSON.parse(JSON.stringify(message).message));
}

function addschedule(){
	
    let c = document.getElementById("c"); 
	let pop = document.getElementById("popup");
	let teCode = document.getElementsByName("tCode")[0].value;
	let teName = document.getElementsByName("teName")[0].value;
	
	let schedule = document.getElementById("schedule");
    let schedule1 = "<select name = 'teCode'><option label = '팀선택'></option>";
	const tCode = teCode.split(",");
	const tName = teName.split(",");

	c.style.display= "block";
	pop.style.display= "block";
	
	
	
	for(i=0; i<tCode.length; i++){
		schedule1 +="<option value=\'"+tCode[i]+"\'>"+ tName[i]+"</option>";
	} 
	 schedule1 += "</select>";
	
	
	schedule.innerHTML = schedule1;
	

}

function checkOnly(element) {
  
  let x = document.getElementsByName("open");

for(i=0; i<x.length; i++){
     if(x[i] != element){
	  x[i].checked = false;
}	
}
}
function newSd(){ //첫번쨰

	
	let List = document.getElementById("List");
	let sText = "";
    
	/*	
		memberList.innerHTML = jsonData[index].mbName + jsonData[index].mbId;
	}
	*/

		
	sText += "<input type = 'file' name = 'imgFile' /><button id = 'plusimg' onClick = 'addimg()' >ADD</button><button id = 'remove' onClick = 'deleteimg()' >DELETE</button>";
	
	List.innerHTML = sText;

}




function addimg(){ //추가
	
	let addimg = document.getElementById("addimg");
	
	
	if(count<4){
		addimg.innerHTML +=  "<div><input type = 'file' name = 'imgFile'/><button id = 'plusimg' onClick = 'addimg()' >ADD</button><button id = 'remove' onClick = 'deleteimg(this)' >DELETE</button></div>";
       
        count++;
	}
	
}

function deleteimg(child){

   let parent = child.parentNode;
   parent.parentNode.removeChild(parent);
   count--;
}

function submitSchedule(){
	
	let f = document.getElementsByName("form")[0];
	f.submit();
	

}


