function makeform(action, method){
	let f = document.createElement("form");
	
	f.setAttribute("action", action);
	f.setAttribute("method", method);
	
	return f;
	
}

  function mailAuth(){
	
   let f = document.createElement("form");
   let mbId = document.getElementsByName("mbId")[0];
   let teCode = document.getElementsByName("teCode")[0];
     

     f.appendChild(mbId);
     f.appendChild(teCode);
   
     document.body.appendChild(f);

     f.action = "authConfirm";
     f.method = "post";
      
     f.submit();
          
    	
    }
  