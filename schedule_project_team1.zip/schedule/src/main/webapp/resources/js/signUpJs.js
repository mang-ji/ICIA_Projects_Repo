/**
 * 
 */

function idDupCheck(obj){
    		
    		let uCode = document.getElementsByName("uCode")[0];
    		
		
    	if(obj.innerText != "재입력"){
    	        // 아이디 유효성 검사
    	        if(isIdCheck(uCode.value)<2){
    	           uCode.value = "";
    	           uCode.focus();
    	           return;
    	      }
                    
             getAjax("IsDup", "uCode="+uCode.value, "pressDupCheck");
    	        
    	     }else{
				
    	        uCode.value = "";
    	        uCode.readOnly = false;
    	        uCode.focus();
    	        obj.innerText = "중복검사";   
    	     }

    	}
    	//{message:true}
    	function pressDupCheck(jsonData){

    		let dup = document.getElementById("dup");
    		let uCode = document.getElementsByName("uCode")[0];
    		let message = document.getElementsByName("idCheckText")[0];
    		
    		if(jsonData == true){
    			uCode.setAttribute("readOnly", true);
    			dup.innerText = "재입력";
    			message.innerText = "사용 가능한 아이디입니다.";
    		} else{
    			uCode.setAttribute("value", "");
    			message.innerText = "사용 불가능한 아이디입니다.";
                message.className = "changeCheckText2";
    			uCode.focus();
    		}
    	}
	

function sendJoinInfo(){
	
	const t = /[A-Z]/g;
	const kor = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g;
	const uCode = document.getElementsByName("uCode")[0];
	const aCode = document.getElementsByName("aCode");
	const uName = document.getElementsByName("uName")[0];
	const uPhone = document.getElementsByName("uPhone")[0];
	const Mail = document.getElementsByName("Mail");
    const file = document.getElementsByName("file1")[0];
	
	//비밀번호

	if(t.test(aCode[0].value)== true && isPasswordCheck(aCode[0].value) < 3  &&  8 > aCode[0].value.length || aCode[0].value.length>20 || aCode[0].value != aCode[1].value ){
		aCode[0].value=""; aCode[1].value="";
		aCode[0].focus();
		return;
	}
	
	//아이디
	if(isIdCheck(uCode.value)<2 && uCode.value.length <6 || uCode.value.length>12){
		uCode.value ="";
		uCode.focus();
		return;
		
	}
	
	

	
	
	// 사용자명 입력여부 체크
	if(uName.value == "" || kor.test(uName.value) == false || !charCount(uName.value,2,5)){
		uCode.value="";
		uName.focus();
		return;
	}
	
	
	
	let uMail = makeInput(Mail[0].value+Mail[1].value, "uMail", "hidden");
	
	
	let f = makeMultiPartform("join", "post");
	f.appendChild(uCode);
	f.appendChild(aCode[0]);
	f.appendChild(uName);
	f.appendChild(uPhone);
	f.appendChild(uMail);
	f.appendChild(file);
	
	
	document.body.appendChild(f);
	
	f.submit();
	
}

function makeMultiPartform(action, method, enctype, name = null){
	let f = document.createElement("form");
	
	
	if(name!= null){
		f.setAttribute("name", name);
	}
	f.setAttribute("action", action);
	f.setAttribute("method", method);
	f.setAttribute("enctype", "multipart/form-data");
	
	return f;
	
}

function makeInput(value, name, type){
	let input = document.createElement("input");
	
	input.setAttribute("value", value);
	input.setAttribute("name", name);
	input.setAttribute("type",type);
	
	return input;
	
}


function isIdCheck(word){
	const cuComp = /^[a-z]{1}[a-z0-9]{5,11}$/;
	
	const sEng = /[a-z]/;
	const num = /[0-9]/;
	
	let count = 0;
	
	if(sEng.test(word)){count++; }
	if(num.test(word)){count++; }	

	
	return count;
}

function isPasswordCheck(word){
	const sEng = /[a-z]/;
	const num = /[0-9]/;
	const special = /[!@#$%^&*]/; 

	let count = 0;
	
	if(sEng.test(word)){count++; }
	if(num.test(word)){	count++; }	
	if(special.test(word)){count++; }
	
	return count;
}

function postAjax(jobCode, clientData, fn){
	
	let ajax = new XMLHttpRequest();
	
	ajax.onreadystatechange = function(){
	if(ajax.onreadystatechange == 4 && ajax.status == 200){
		window[fn](JSON.parse(ajax.responseText));
		
	  }
	
   };

       ajax.open("POST", jobCode);
       ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
       ajax.send(clientData);
}

function getAjax(jobCode, clientData, fn){
	/* Step1 */
	let ajax = new XMLHttpRequest();
	
	/* Step2 */
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[fn](JSON.parse(ajax.responseText));
		}
		
	};
	/* Step3 */
	if(clientData !=""){
		jobCode += "?" + clientData;
	}
	ajax.open("GET", jobCode);
	/* Step4 */
	ajax.send();
}

function idCheck(){
	let changeText = document.getElementsByName("idCheckText")[0];
	let id = document.getElementsByName("uCode")[0];
	
	if(isIdCheck(id.value)<2 ){
		changeText.innerText = "아이디는 소문자와 숫자를 결합하여 6~12자리로 입력해주세요.";
		changeText.className = "checkText";	
	}else if(id.value <6 || id.value>12){
		changeText.innerText = "아이디는 소문자와 숫자를 결합하여 6~12자리로 입력해주세요.";
		changeText.className = "checkText";
	}else{
		changeText.innerText = "조건에 부합합니다. 중복검사를 해주세요.";
	    changeText.className = "changeCheckText";	
		
	}
	
	
	}
	
function pwdCheck(){
		const t = /[A-Z]/g;
	let pwdCheckText = document.getElementsByName("pwdCheckText");
	let pwd = document.getElementsByName("aCode");
	
	    if(isPasswordCheck(pwd[0].value) < 3){
		pwdCheckText[0].innerText = "비밀번호는 소문자,숫자,특수문자를 결합하여 8~20자리로 입력해주세요.";
		pwdCheckText[0].className = "checkText";
		
	}else if(8 > pwd[0].value || pwd[0].value>20){
		pwdCheckText[0].innerText = "비밀번호는 소문자,숫자,특수문자를 결합하여 8~20자리로 입력해주세요.";
		pwdCheckText[0].className = "checkText";
		
	}else if(t.test(pwd[0].value) == true ){
		pwdCheckText[0].innerText = "비밀번호는 소문자,숫자,특수문자를 결합하여 8~20자리로 입력해주세요.";
		pwdCheckText[0].className = "checkText";
	
	}else{	pwdCheckText[0].innerText = "안전합니다.";
		pwdCheckText[0].className = "changeCheckText";
		
		}
		
	}
	
function pwdDupCheck(){
	let pwdCheckText = document.getElementsByName("pwdCheckText");
	let pwd = document.getElementsByName("aCode");
						
	if(pwd[0].value != pwd[1].value){
		pwdCheckText[1].innerText = "비밀번호를 다시 입력해주세요.";
		pwdCheckText[1].className = "checkText";
		}else{
			pwdCheckText[1].innerText = "비밀번호가 일치합니다.";
			pwdCheckText[1].className = "changeCheckText";
		}
	}


function korCheck(obj, event){
	const pattern = /^[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]+$/;
	
	if(pattern.test(event.target.value.trim())) {
		obj.value = obj.value.replace(pattern,'').trim();
	}
}

function charCount(word, min, max){
	return word.length >= min && word.length <= max;
}

function nameCount(obj){
	const kor =/^[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]+$/;
	
    if(!charCount(obj.value,0,5) ){
	obj.value = "";
	obj.focus();
	
}
    if(kor.test(obj.value) == false){
	obj.value = "";
	obj.focus();
	
}
}

function uploadFile(){
	
	let file2 = document.getElementsByName("file1")[0];
	let f = document.createElement("form");
	f.setAttribute("action", "upload");
	f.setAttribute("method", "post");
	f.enctype = "multipart/form-data";
	f.appendChild(file);
	document.body.appendChild(f);
	f.submit();
	
}




	

