

function inviteSite(){
	
   let invite = document.getElementsByName("invite")[0];
	
	let f = document.createElement("form");
	
	f.appendChild(invite);
	
	f.action = "signUp";
	f.method = "get";
	
	document.body.appendChild(f);
	
	f.submit();
}