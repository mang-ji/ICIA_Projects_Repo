package one.user.bean;

import java.util.List;

import lombok.Data;

@Data
public class AlbumBean {
	
	private String[] stickerPath;
	private String teCode;
	private int num;

}
