package one.user.bean;


import lombok.Data;

@Data
public class AccessInfo {
	
	private String uCode;
	private String aCode;
	private int method;
	private String publicIp;
	private String privateIp;
	private String browser;
	private String teCode;
	private String teName;
	
//로그인 할 때 기록을 남김(insert)
}
