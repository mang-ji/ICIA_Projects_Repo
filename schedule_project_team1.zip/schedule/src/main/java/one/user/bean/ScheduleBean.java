package one.user.bean;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class ScheduleBean {
	
	private String teCode;
	private String teName;
	private int num;
	private String mbId; 
	private String mbName;
	private String title;
	private String date;
	private String location;
	private String contents;
	private String process;
	private String prName;
	private String open;
	private String opName;
	private String loop;
	private String loName;
	private List<MultipartFile> imgFile;
	private String stickerPath;
	private List<UserBean> userbean;

	//private List<AlbumBean> album;


}
