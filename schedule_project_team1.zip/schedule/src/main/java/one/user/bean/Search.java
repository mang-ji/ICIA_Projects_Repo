package one.user.bean;

import java.util.List;

import lombok.Data;

@Data
public class Search {
	
	private String word;
	private String mbId;
	private String mbName;
	private String mail;
	//private List<TDetails> tdetails;
	

}
