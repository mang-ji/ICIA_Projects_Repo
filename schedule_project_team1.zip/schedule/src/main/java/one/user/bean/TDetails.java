package one.user.bean;

import java.util.List;

import lombok.Data;

@Data
public class TDetails {
	
	private String teCode;
	private String mbId;
	private String mbId2;
	private String cgCode;
	private String cgName;
	private String mbName;
	private String mail;
	private String frId;
	private String fr_accept;
	private List<UserBean> userbean;
	
	
	

}
