package one.user.bean;

import java.util.List;

import lombok.Data;




@Data
public class TeamBean {
	
	private String teCode;
	private String teCodeNum;
	private String teName;
	private String mbId;
	private String eMail;
	private List<TDetails> tdetails; //친구목록 멤버 아이디 
	

}
