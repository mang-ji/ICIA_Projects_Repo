package one.services.auth;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import one.project.util.Encryption;
import one.project.util.ProjectUtil;
import one.user.bean.AccessInfo;
import one.user.bean.UserBean;


@Service
public class Authentication {

	@Autowired
	AuthDao dao;
	@Autowired
	Gson gson;
	@Autowired
	Encryption enc;
	@Autowired
	ProjectUtil pu;
	private ModelAndView mav;
	boolean check;




	public ModelAndView rootCtl(AccessInfo ai) {
		mav = new ModelAndView();
		String view = "logIn";

		try {
			if(pu.getAttribute("uCode") != null) {
				mav.addObject("uCode", enc.aesEncode((String)pu.getAttribute("uCode"), "mangji"));
				mav.addObject("uName", enc.aesDecode((String)pu.getAttribute("uName"), (String)pu.getAttribute("uCode")));
				view = "dashBoard";
				if(ai.getUCode()!=null) {
					if(!dao.isCurrentAccess(ai)) {
						pu.removeAttribute("uCode");
						mav.setViewName("logIn");
						mav.addObject("message","다른 곳에서 로그인하여 직전 세션은 해제되었습니다.");

					}
				}
			}

		} catch (Exception e) {e.printStackTrace();}
		mav.setViewName(view);
		return mav;

	}

	public ModelAndView joinform() {
		mav = new ModelAndView();
		mav.setViewName("signUp");

		return mav;

	}


	public ModelAndView logInCtl(AccessInfo ai ) {
		mav = new ModelAndView();
		String encPwd = null, view = "redirect:/", message = null;
		boolean check = true;
		StringBuffer teCode = new StringBuffer();
		StringBuffer teName = new StringBuffer();

		  
		

		try {

			if(pu.getAttribute("uCode")==null) {
				/*마지막 로그인 기록 확인 후 다른 브라우저나 ip가 다르다면 강제 로그아웃*/
				if(dao.isAccess(ai)) {
					check = dao.forceLogOut(ai);

				}


				if(check) {
					encPwd = dao.isAccessInfo(ai);
					if(check=(encPwd!=null)) {
						if(check = enc.matches(ai.getACode(), encPwd)) {
							if(check = dao.insAccessHistory(ai)) {

								mav.setViewName("redirect:/");
								pu.setAttribute("uCode", ai.getUCode());
								mav.addObject("uCode", enc.aesEncode(ai.getUCode(), "mangji"));
								pu.setAttribute("uName", dao.selMemberInfo(ai).get(0).getUName());
								mav.addObject("uName", enc.aesDecode(dao.selMemberInfo(ai).get(0).getUName(), ai.getUCode()));
								pu.setAttribute("images", dao.selMemberInfo(ai).get(0).getStickerPath());
								
								for(int i=0; i<dao.teamInfo(ai).size(); i++) {
								    teCode.append(dao.teamInfo(ai).get(i).getTeCode()+",");
								    teName.append(dao.teamInfo(ai).get(i).getTeName()+",");
								    
								}
								pu.setAttribute("teCode", teCode.toString().substring(0, teCode.toString().length()-1));
								pu.setAttribute("teName", teName.toString().substring(0, teName.toString().length()-1));
								
								System.out.println(teCode.toString().substring(0, teCode.toString().length()-1));
								System.out.println(teName.toString().substring(0, teName.toString().length()-1));
							}
						}
					}
					message = (check)?"로그인 성공":"로그인 정보를 다시 확인해주시거나 잠시후 다시 시도해주세요.";
				}else {
					message = "직전 로그인 기록을 삭제하지 못하였습니다. 잠시 후 다시 시도해주세요.";
				}
			}else {
			}

		}catch (Exception e) {
			e.printStackTrace();}
		finally {
			mav.setViewName(view);
			mav.addObject("uCode",ai.getUCode());
			mav.addObject("publicIp",ai.getPublicIp());
			mav.addObject("privateIp",ai.getPrivateIp());
			mav.addObject("browser",ai.getBrowser());
			mav.addObject("message",message);



		}
		
             
		

		return mav;

	}

	public ModelAndView logOutCtl(AccessInfo ai) {
		mav = new ModelAndView();
		boolean check = false;
		try {

			ai.setUCode(enc.aesDecode(ai.getUCode(), "mangji"));

			if(pu.getAttribute("uCode")!=null) {

				while(!check) {

					check = dao.insAccessHistory(ai);

				}

				pu.removeAttribute("uCode");
				mav.setViewName("redirect:/");
				pu.setAttribute("message", "정상적으로 로그아웃이 되었습니다.");

			}else {

				mav.setViewName("redirect:/");
				pu.setAttribute("message", "이미 로그아웃이 되었습니다.");
			}

		}catch (Exception e) {

			e.printStackTrace();
		}


		//HttpSession session = req.getSession();
		//session.invalidate();

		return mav;
	}

	public ModelAndView joinCtl(UserBean ub) {

		mav = new ModelAndView();
		mav.setViewName("join");
		mav.addObject("message", "음... 다시 시도해주세요.");
           

		try {
			ub.setUName(enc.aesEncode(ub.getUName(), ub.getUCode()));
			ub.setUMail(enc.aesEncode(ub.getUMail(), ub.getUCode()));
			ub.setUPhone(enc.aesEncode(ub.getUPhone(), ub.getUCode()));

			  if(ub.getFile1().isEmpty()){
		            ub.setStickerPath("");
		            
		         }else {
		            ub.setStickerPath(("/resources/images/" + pu.savingFile(ub.getFile1())));
			//			ub.setUMail(enc.TripleDesEncoding(uMail, uCode));
			//			ub.setUMail(enc.TripleDesDecoding(ub.getUName(), ub.getUCode()));
			//			ub.setUMail(enc.TripleDesDecoding(ub.getUMail(), ub.getUCode()));
		} 
		}catch (Exception e) {
			e.printStackTrace();
		}

		ub.setACode(enc.encode(ub.getACode()));
		if(dao.insMembers(ub)){
			mav.setViewName("logIn");
			mav.addObject("message", "환영해요!");

		}

		return mav;

	}


	public String isDuplicateId(AccessInfo ai) {
		boolean message = false;

		if(!dao.isUserId(ai)) {
			message = true;
		}


		return gson.toJson(message);
	}
    
	

	/*joinCtl*/
	private boolean insMemeber(UserBean ub) {

		return false;	
	}

	/*accessCtl, joinCtl,isDuplicatieId*/
	private boolean isUcode(AccessInfo ai) {

		return false;
	}

	/*accessCtl 하지만 언제든 재활용은 가능*/
	private boolean isAccess(AccessInfo ai) {

		return false;
	}

	/*accessCtl*/
	private boolean insAccessHistory(AccessInfo ai) {

		return false;

	}


}
