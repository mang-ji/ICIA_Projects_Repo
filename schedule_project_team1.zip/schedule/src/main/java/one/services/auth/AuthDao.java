package one.services.auth;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import one.user.bean.AccessInfo;
import one.user.bean.UserBean;

@Repository //싱글톤으로 올라감
public class AuthDao {
	
	@Autowired
	SqlSessionTemplate sqlSession;

	
	boolean isUserId(AccessInfo ai) {
		return this.convertDataType(sqlSession.selectOne("isUserId", ai));
	}

	
	String isAccessInfo(AccessInfo ai) {
		return sqlSession.selectOne("isAccessInfo", ai);
	}
     
	
	boolean isAccess(AccessInfo ai) {
		return this.convertDataType(sqlSession.selectOne("isAccess",ai));
	}
	
	 boolean forceLogOut(AccessInfo ai) {
		 return this.convertDataType(sqlSession.insert("forceLogOut",ai));
	 }
	 

	 boolean isCurrentAccess(AccessInfo ai) {
		
		return this.convertDataType(sqlSession.selectOne("isCurrentAccess",ai));
	}
	
	
	 boolean insAccessHistory(AccessInfo ai) {
		
		return this.convertDataType(sqlSession.insert("insAccessHistory", ai));

	}
	List<AccessInfo> teamInfo(AccessInfo ai) {
		 return sqlSession.selectList("teamInfo", ai);
	 }

	
	 boolean insMembers(UserBean ub) {
		return this.convertDataType(sqlSession.insert("insMembers", ub));

	}
	 boolean logOutCheck(AccessInfo ai) {
		//int minus =  sqlSession.selectOne("selAhMinus", ai);
		// int plus = sqlSession.selectOne("selAhPlus", ai);
		//int sessionCheck =  sqlSession.selectOne("logOutCheck", ai);
		 int bCheck = sqlSession.selectOne("logOutCheck", ai);
	   
		return (bCheck ==0)? true:false;
		
	 }
	 
	String browserLogout(AccessInfo ai) {
		//가장 최근 로그인된 브라우저 이름을 넘김
		 return sqlSession.selectOne("browserLogout",ai);
	 }
	
	boolean insbrowser(AccessInfo ai) {
		
		return this.convertDataType(sqlSession.insert("insAccessHistory",ai));
		
	}
	 
	 
	 
	
	List<UserBean> selMemberInfo(AccessInfo ai){
		
		return sqlSession.selectList("selMemberInfo", ai);
		
	}
	
	
	 boolean convertDataType(int value) {
		return (value >0)?true:false;
	}
      


}
