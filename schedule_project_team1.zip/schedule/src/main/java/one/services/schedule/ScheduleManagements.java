package one.services.schedule;

import one.database.mapper.ScheduleInterface;

public class ScheduleManagements implements ScheduleInterface{

}
