package one.services.share;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.servlet.ModelAndView;

import one.database.mapper.ShareInterface;
import one.project.util.Encryption;
import one.project.util.ProjectUtil;
import one.user.bean.ScheduleBean;
import one.user.bean.Search;
import one.user.bean.TDetails;
import one.user.bean.TeamBean;
import one.user.bean.UserBean;


@Service
public class Share implements ShareInterface{
	@Autowired
	Encryption enc;
	@Autowired
	ProjectUtil pu;
	@Autowired
	SqlSessionTemplate sqlSession;
	@Autowired
	DataSourceTransactionManager tx;
	@Autowired
	JavaMailSenderImpl javaMail;
	private DefaultTransactionDefinition def;
	private TransactionStatus status;
	private ModelAndView mav;

	public Share() {

	}


	public List<TeamBean> getTeamList(TeamBean tb){
		List<TeamBean> teamList;
		teamList = sqlSession.selectList("getTeamList", tb);

		return teamList;
	}


	public List<TDetails> getMemberList(TDetails td) {
		List<TDetails> memberList;

		memberList = sqlSession.selectList("getMemberList", td);

		for(int index=0; index < memberList.size(); index++) {
			try{
				memberList.get(index).setMbName(enc.aesDecode(memberList.get(index).getMbName(), memberList.get(index).getMbId()));
			}catch (Exception e) {

				e.printStackTrace();
			} 
		}



		return memberList;
	}

	@Transactional 
	public List<TeamBean>addTeam(TeamBean tb) {
		this.setTransactionConf(TransactionDefinition.PROPAGATION_REQUIRED, TransactionDefinition.ISOLATION_READ_COMMITTED,false);

		try {
			if(this.countNum()!=null) {
				tb.setTeCodeNum(countNum());
				if(this.insTeam(tb)) {

					tb.setMbId((String)pu.getAttribute("uCode"));
					tb.setTeCode(this.newOne());
					//tb.setTeCode("123456789");
					this.insLeader(tb);
					this.setTransactionResult(true);
				}

				//			}else{
				//				
				//				if(this.insTeam(tb)) {
				//					try {
				//						tb.setMbId((String)pu.getAttribute("uCode"));
				//						tb.setTeCode(this.newOne());
				//						this.insLeader(tb);
				//						System.out.println("여깅");
				//					} catch (Exception e) {
				//				     
				//						e.printStackTrace();
				//					}
				//			
				//		}
			}	

		}catch(Exception e) {
			System.out.println("실패");
			this.setTransactionResult(false);
			e.printStackTrace();
		}
		return this.getTeamList(tb);

		//select 오늘 날짜의 몇 번까지 만들어졌는지 확인하깅

		//숫자값 증가시키기 001,002,003 ...

		//TE 테이블에 INSERT
		//TD 테이블에 INSERT
		//getTeamList 호출을 통해 갱신된 데이터 가져오기 



	}



	public String countNum() {
		int number=0;

		if(sqlSession.selectOne("countNum")==null) {
			number = 0;


		}else {
			number = sqlSession.selectOne("countNum");

		}


		String result = (number+1) + "";

		for(int add = result.length(); add<3; add++) {
			result = "0"+result;
		}


		return result;

	}

	public List<TDetails> frList(TDetails td){ //친구 추가 > 친구 출력 
             
		List<TDetails> frList;
		
		frList = sqlSession.selectList("frList", td); 
		
        
		for(int index=0; index < frList.size(); index++) {
			try{
				frList.get(index).setMbName(enc.aesDecode(frList.get(index).getMbName(), frList.get(index).getMbId()));
			}catch (Exception e) {

				e.printStackTrace();
			} 
		}
       
  
		return frList;

	}
	
	public void insFr(List<TDetails> list2){//메일보내기 0 insert하기
		
		//list2.get(0).getUserbean().get(0).setUMail(this.getMail2(list2).get(0).getMail());
		if(this.sendFr(list2)!=null) {
			list2.get(0).setMbId2(list2.get(0).getUserbean().get(0).getUCode());
			System.out.println(list2.get(0).getUserbean().get(0).getUCode());
			System.out.println("여기가 인서트 성공!");
			this.addFr(list2.get(0));
			
		}
		
		
	}
	
	public boolean clickNo(TDetails td) {
		
		return this.convert(sqlSession.delete("clickNo", td));
	}
	

	public boolean insTeam(TeamBean tb) {

		return this.convert(sqlSession.insert("insTeam", tb));
	}

	public boolean insLeader(TeamBean tb) {

		return this.convert(sqlSession.insert("insLeader", tb));
	}
	public boolean insMember(TeamBean tb) {

		return this.convert(sqlSession.insert("insMember",tb));
	}

	public boolean convert(int value) {

		return (value>0)? true:false;

	}
	
	public boolean addFr(TDetails td) {
		
		return convert(sqlSession.insert("addFr", td));
		
	}
	
	public boolean clickYes(TDetails td) {
		
		return this.convert(sqlSession.update("clickYes",td));
	}

	public String newOne() {

		return sqlSession.selectOne("newOne");

	}
	
	public ModelAndView upFr(TDetails td) {
	     mav = new ModelAndView();
		
		if(this.clickYes(td)) {
			mav.setViewName("logIn");
		}
				
				return mav;
		
	}

	//Transaction Configuration
	private void setTransactionConf(int propagation, int isolationLevel, boolean isRead) {
		def = new DefaultTransactionDefinition();
		def.setPropagationBehavior(propagation);
		def.setReadOnly(isRead);
		status = tx.getTransaction(def);
	}

	//Transaction Result
	private void setTransactionResult(boolean isCheck) {
		if(isCheck) {
			tx.commit(status);
		}else {
			tx.rollback(status);
		}
	}

	private void friendsAuth(List<TDetails> td) {//메일작성, 전송
		
		String subject = "Invitation";
		String contents = "<a href = 'http://172.30.1.18/mailAuth?mbId="+td.get(0).getMbId()+"&teCode="+td.get(0).getTeCode()+"'>클릭하여 수락을 해주세요.</a>";

		String from = "alswlsms555@naver.com";
		String[] to = new String[td.size()];
		
	
		
		for(int index=0; index<td.size(); index++) {
			to[index] = td.get(index).getMail();
			
		}

		MimeMessage mail = javaMail.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail, "UTF-8");

            
		try {
			helper.setFrom(from);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(contents,true);

			javaMail.send(mail);
		} catch (MessagingException e) {

			e.printStackTrace();
		}

	}


	public List<TDetails> addMember(TeamBean tb) {
		
		
//		for(int i=0; i<tb.getTdetails().size(); i++) {
//                     
//			try {
//				
//				tb.getTdetails().get(i).setMail(enc.aesDecode(this.getMail(tb.getTdetails()).get(i).getMail(), tb.getTdetails().get(i).getMbId()));
//				//			tb.getTdetails().get(i).setMail(enc.aesDecode(this.getMail(tb), tb.getMbId()));
//				
//			} catch (Exception e) {
//
//				e.printStackTrace();
//			} 
//
//		}
//		
		
		
		
		//tb.getTdetails().get(0).setMail("i_innew0731@naver.com");
		//tb.getTdetails().get(1).setMail("alswlsms555@gmail.com");
           this.getMail(tb.getTdetails());
		tb.getTdetails().get(0).setTeCode(tb.getTeCode());
		this.friendsAuth(tb.getTdetails());

		return getMemberList(tb.getTdetails().get(0));
	}

	public ModelAndView mailConfirm (TeamBean tb) {
		mav = new ModelAndView();
        
		if(this.insMember(tb)) {

			mav.setViewName("logIn");
		}

		return mav;


	}

	public List<TDetails> getMail(List<TDetails>td){

                      
		for(int index=0; index<td.size(); index++) {

			td.get(index).setMail(sqlSession.selectOne("getMail", td.get(index).getMbId()));
		}
		
		for(int i=0; i<td.size(); i++) {


			try {
				td.get(i).setMail(enc.aesDecode(td.get(i).getMail(),td.get(i).getMbId()));
			} catch (Exception e) {
				e.printStackTrace();
			} 
			
		}

		return td;

	}
	
	public List<TDetails> getMail2(List<TDetails>td){

        
		for(int index=0; index<td.size(); index++) {

			td.get(index).setMail(sqlSession.selectOne("getMail2", td.get(index).getUserbean().get(index).getUCode()));
		}
		
		for(int i=0; i<td.size(); i++) {


			try {
				td.get(i).setMail(enc.aesDecode(td.get(i).getMail(),td.get(i).getUserbean().get(i).getUCode()));
			} catch (Exception e) {
				e.printStackTrace();
			} 
			
		}

		return td;

	}
	
	


//	public List<TDetails> word(Search search) {
//
//		//alswlsms555김민지
//
//		//		try {
//		//			
//		//			search.setWord(enc.aesEncode(search.getWord(), this.allMember().get(0).getUCode())); //김민지 > 암호화
//		//			
//		//			
//		//		} catch (Exception e1) {
//		//			
//		//			e1.printStackTrace();
//		//		} 
//
//		//this.searchFr(search);
//
//		//List<TDetails> list2  = sqlSession.selectList("word", search);
//		//		 
//		//			for(int i=0; i<list2.size(); i++) {
//		//				try {
//		//				    
//		//					list2.get(i).setMbName(enc.aesDecode(list2.get(i).getMbName(), list2.get(i).getMbId()));
//		//					list2.get(i).setMail(enc.aesDecode(list2.get(i).getMail(), list2.get(i).getMbId()));
//		//					
//		//				} catch (Exception e) {
//		//				
//		//					e.printStackTrace();
//		//			}
//		//			
//		//		}
//		//	
//		List<TDetails> result;
//		int i=0; i<result.size(); i++) {
//
//			this.searchFr(search).get(i).getMail();
//			this.searchFr(search).get(i).getMbName();
//
//
//		}
//
//		return list2;
//	}

	public List<Search> searchFr(Search search) {
		List<Search> result = new ArrayList<Search>();
		
		//System.out.println(this.allMember().get(0).getMail()+":"+this.allMember().get(0).getMbId()+":"+this.allMember().get(0).getMbName());
		
		for(int index=0; index<this.allMember().size(); index++) {
			Search bean = new Search();
			try {
				
				bean.setMail(enc.aesDecode(this.allMember().get(index).getMail(), this.allMember().get(index).getMbId()));
			    bean.setMbName(enc.aesDecode(this.allMember().get(index).getMbName(), this.allMember().get(index).getMbId()));
				bean.setMbId(this.allMember().get(index).getMbId());
			
                       

		if ((bean.getMail()+bean.getMbName()+bean.getMbId()).contains(search.getWord())) {
	                    
					result.add(bean);
					
				
			}
		
		   
			
			} catch (Exception e1) {

				e1.printStackTrace();
			}

		}
		
		//search.setWord(search.getUMail()+search.getUName());

           //System.out.println("여기얌");
           
		return result; //alswlsms555김민지
	}

	public List<Search> allMember(){
                         
		return sqlSession.selectList("allMember");

	}




	public Map<String, String> mail2(List<TDetails> td) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("message", "친구 요청 메일을 보냈습니다.");
		String subject = "Invitation";
		String contents = "<a href = 'http://172.30.1.18/inviteFr'>클릭하여 회원가입을 먼저 진행해주세요!</a>";

		String from = "alswlsms555@naver.com";
		String[] to = new String[td.size()];
		
	
		
		for(int index=0; index<td.size(); index++) {
			to[index] = td.get(index).getMail();
			
		}

		MimeMessage mail = javaMail.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail, "UTF-8");

            
		try {
			helper.setFrom(from);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(contents,true);

			javaMail.send(mail);
		} catch (MessagingException e) {

			e.printStackTrace();
		}
		
		return map;
		
	}


	public Map<String, String> sendFr(List<TDetails> td) {
		Map<String, String> map = new HashMap<String, String>();
	   
		String subject = "Invitation";
		String contents = "<a href = 'http://172.30.1.18/addFr?mbId="+td.get(0).getMbId()+"&mbId2="+td.get(0).getUserbean().get(0).getUCode()+"'>클릭하여 친구가 되어주세요!</a>";
		                  

		String from = "alswlsms555@naver.com";
		String[] to = new String[td.size()];
		
	
		
		for(int index=0; index<td.size(); index++) {
			to[index] = this.getMail2(td).get(index).getMail();	
			
		
		}

		MimeMessage mail = javaMail.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail, "UTF-8");

            
		try {
			helper.setFrom(from);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(contents,true);

			javaMail.send(mail);
		} catch (MessagingException e) {

			e.printStackTrace();
		}
		
		return map;
	}


	public ModelAndView delFr(TDetails td) {
	 mav = new ModelAndView();
		
		if(this.clickNo(td)) {
			mav.setViewName("signUp");
		}
		System.out.println("여긴 no 누른 거얌!");
		return mav;
	}


	public ModelAndView addPhotos(ScheduleBean sb) {
		ModelAndView mav = new ModelAndView();
		List<ScheduleBean> list = new ArrayList<ScheduleBean>();
		
	            for(int i=0; i< sb.getImgFile().size(); i++) {
	                //sb.setStickerPath(("/resources/images/"+pu.savingFile(sb.getImgFile().get(i))));
	                 sb.setTeCode("210804001");
	                 sb.setNum(1);
	                //this.insAlbum(sb);
	                mav.setViewName("schedule");
	               
	              
	             
	             }
	            for(int n=0; n<this.selPhoto(sb).size(); n++) {
	            mav.addObject("photos_"+n+"",this.selPhoto(sb).get(n).getStickerPath());
                //pu.setAttribute("img", sb.getStickerPath());
	           // System.out.println(this.viewPhotos(sb));
	            }
	            
		return mav;
	}


	public boolean insAlbum(ScheduleBean sb) {
		
		return this.convert(sqlSession.insert("insAlbum", sb));
		
	}
	
	
	
	public List<ScheduleBean> selPhoto(ScheduleBean sd){
		
		return sqlSession.selectList("selPhoto", sd);
	}
	
	public Map<String, Object> viewPhotos(ScheduleBean sd) {
		
		Map<String, Object> map = new HashMap<String, Object>();
		for(int i=0; i<sd.getImgFile().size(); i++) {
		map.put("photos", this.selPhoto(sd).get(i).getStickerPath());
		}
		
		return map;
	}


	public ModelAndView addSchedule(ScheduleBean sd) {
		ModelAndView mav = new ModelAndView();
		sd.setDate(sd.getDate().replace("-", ""));
		 this.schedule(sd);
		 for(int i=0; i<sd.getImgFile().size(); i++) {
		 sd.setStickerPath(("/resources/images/"+pu.savingFile(sd.getImgFile().get(i))));
			 this.insAlbum(sd);
		 }
		 
	         mav.setViewName("logIn");
	return mav;
	}
	
	public boolean schedule(ScheduleBean sd) { //스케줄 넣기
		
		return this.convert(sqlSession.insert("schedule", sd));
	}
	
	public List<ScheduleBean> selSchedule(ScheduleBean sd){
		List<ScheduleBean> sdList;
		 sd.setDate(sd.getDate().replace("-", "").substring(0,6));
		 sdList = sqlSession.selectList("selSchedule", sd);
		 
		 return sdList;
	}


	public ModelAndView viewSd(ScheduleBean scheduleBean) {
		ModelAndView mav = new ModelAndView();
     this.selSchedule(scheduleBean);
     
     mav.setViewName("redirect:/");
     
     return mav;
		
	}
		

	/*DATASOURCETRANSACTIONMANAGER
	 * -선언적 트랜재션: AOP방식
	 * @Transactional 어노테이션을 이용해 클래스나 하위 메서드에 적용 가능
	 * >>>관련된 메서드는 반드시 public, default 접근 제한자를 사용해야 합니다.
	 * - (우리가 지금 구현하려고 하는 것) 명시적 트랜잭션 Programa Transaction
	 * 
	 * 환경설정
	 * >propagationn:전파방식
	 *  --insert하고 insert하고 delete를 하면 트랜잭션이 셋인데 이걸 하나로 묶을지 각자 하나씩 할지
	 *  -- TRAN      TRAN      TRAN 을 집어넣어서 하나의 묶음으로 만든다
	 *  
	 *
	 * 
	 * 
	 * PROPAGATION
	 * -REQUIRED: DEFAULT VALUE
	 * 
	 * 
	 *  >isolation: 격리수준
	 * 
	 * 
	 * */





}
