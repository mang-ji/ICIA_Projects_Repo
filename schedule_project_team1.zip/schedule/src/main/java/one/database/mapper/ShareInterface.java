package one.database.mapper;



import java.util.List;

import one.user.bean.ScheduleBean;
import one.user.bean.Search;
import one.user.bean.TDetails;
import one.user.bean.TeamBean;
import one.user.bean.UserBean;


public interface ShareInterface {
	
	public List<TeamBean>getTeamList (TeamBean tb);
	public List<TDetails>getMemberList (TDetails td);
	public String countNum();
	public boolean insTeam(TeamBean tb);
	public boolean insLeader(TeamBean tb);
	public String newOne();
	public List<TDetails> frList(TDetails td);
	public boolean insMember(TeamBean tb);
	public List<TDetails> getMail(List<TDetails> td);
	public List<TDetails> getMail2(List<TDetails> td);
	//public List<TDetails> word(Search search);
	public List<Search> allMember();
	public boolean addFr(TDetails td);
	public boolean clickYes(TDetails td);
	public boolean insAlbum(ScheduleBean sd);
	public List<ScheduleBean> selPhoto(ScheduleBean sd);
	public boolean schedule(ScheduleBean sd); 
	public List<ScheduleBean> selSchedule(ScheduleBean sd);
	
}
