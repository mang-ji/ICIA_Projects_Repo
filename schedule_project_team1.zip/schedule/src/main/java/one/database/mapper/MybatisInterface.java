package one.database.mapper;

import java.util.List;

import one.user.bean.AccessInfo;
import one.user.bean.UserBean;



public interface MybatisInterface {

   boolean isUserId(AccessInfo ai);
   boolean isAccessInfo(AccessInfo ai);
   boolean insAccessHistory(AccessInfo ai);
   List<UserBean> selMemberInfo(AccessInfo ai);
   boolean selAhPlus(AccessInfo ai);
   boolean selAhMinus(AccessInfo ai);
   void insMembers(UserBean ub);
   boolean logOutCheck(AccessInfo ai);
  String browserLogout(AccessInfo ai);
  List<AccessInfo> teamInfo(AccessInfo ai);
   
}
