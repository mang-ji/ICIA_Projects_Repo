package one.database.mapper;

public interface AuthInterface {

}
