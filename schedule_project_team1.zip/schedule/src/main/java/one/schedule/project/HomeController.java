package one.schedule.project;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import one.project.util.Encryption;
import one.project.util.ProjectUtil;
import one.services.auth.Authentication;
import one.services.schedule.FileUploadService;
import one.services.share.Share;
import one.user.bean.AccessInfo;
import one.user.bean.ScheduleBean;
import one.user.bean.TeamBean;
import one.user.bean.UserBean;


/**
 * Handles requests for the application home page.
 */

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
     @Autowired
	private Authentication auth;
	private ModelAndView mav;
	@Autowired
	private ProjectUtil pu;
	@Autowired
	private Encryption enc;
	@Autowired
	private Share share;
	@Autowired
	FileUploadService fileUploadService;
	
	
	
	
	@RequestMapping(value = {"/","/logIn","/dashBoard"}, method = {RequestMethod.GET,RequestMethod.POST} )
	public ModelAndView logInform(@ModelAttribute AccessInfo ai) {
	
		return auth.rootCtl(ai);
	}
	
	
	
	@GetMapping("/signUp")
	public ModelAndView signUpform() {
	          
		
		return auth.joinform();
	}
	
	@PostMapping("/sendLogIn")
	public ModelAndView logIn(@ModelAttribute AccessInfo ai) {
		mav = auth.logInCtl(ai);
		return mav;
	}
	
	
	@PostMapping("/join")
	public ModelAndView signUp(@ModelAttribute UserBean ub) {
		
		System.out.println(ub.getFile1().getOriginalFilename());
		System.out.println(ub.getFile1().getContentType());
		//pu.savingFile(ub.getFile1());
		mav = auth.joinCtl(ub);
		
		return mav;
	}
	
	@GetMapping("/IsDup")
	@ResponseBody //ajax로 요청 >> ajax로 받음 (페이지를 바꾸는 것이 아님)>> body의 일부만 반환하겠다
	public String dupCheck(@ModelAttribute AccessInfo ai) {
		
		return auth.isDuplicateId(ai);
	}
	
	@PostMapping("/logOut")
	public ModelAndView signUp(@ModelAttribute AccessInfo ai ) {
		
		mav = auth.logOutCtl(ai);
		
		
		return mav;
	}
	
	@GetMapping("/schedule")
	public String shcheduleManage() {
		return "schedule";
	}

	@GetMapping("/team")
	public String team() {
		return "team";
	}
	
	@GetMapping("/addFr")
	public String addFr() {
		return "addFr";
	}
	
	@GetMapping("/goCalendar")
	public String goCalendar() {
		
		return "newDashboard";
	}
	
	
	
	
	@GetMapping("/mailAuth")
	public ModelAndView mail(@ModelAttribute TeamBean list) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("mailAuth");
		mav.addObject("mbId", list.getMbId());
		mav.addObject("teCode", list.getTeCode());
		
		//System.out.println(list.getTeCode()+":"+list.getMbId());
		
		return mav;
	}
	
	@PostMapping("/authConfirm")
	public ModelAndView authConfirm(@ModelAttribute TeamBean tb) {
		
		System.out.println(tb);
		return share.mailConfirm(tb);
		
	}
	


	@PostMapping("/upload")
	public String upload(Model model, @RequestParam("file1") MultipartFile file) {
		
		fileUploadService.restore(file);
		System.out.println("여기여기여기여기");
		return "/redirect:/";
	}
	
	
	@PostMapping("/addImg")
	public ModelAndView addImg(@ModelAttribute("imgFile") ScheduleBean sd) {
		ModelAndView mav = new ModelAndView();
		
	  //       for(int i=0; i<list3.getImgFile().size(); i++) {
			//System.out.println(list3.getImgFile().get(0).getOriginalFilename());	
//	         }
		mav = share.addPhotos(sd);
		
		return mav;
	}
	
	@PostMapping("/addSchedule")
	public ModelAndView addSchedule(@ModelAttribute ScheduleBean sd) {
		ModelAndView mav = new ModelAndView();
		System.out.println(sd);
	  //       for(int i=0; i<list3.getImgFile().size(); i++) {
			//System.out.println(list3.getImgFile().get(0).getOriginalFilename());	
//	         }
		mav = share.addSchedule(sd);
		
		return mav;
	}
//	@GetMapping("/dashBoard")
//	public String dash() {
//		pping
//		return "dashBoard";
//	}
	
//	@PostMapping("/sendLogIn")
//	public String logInform(@RequestParam("Code") ArrayList<String>list) {
//		System.out.println(list.get(0)+":"+list.get(1));
//		return "logIn";
//	}
	
//	
//	@PostMapping("/sendLogIn")
//	public String logInform(@RequestParam("uCode") String uCode, @RequestParam("aCode") String aCode,
//			                 @RequestParam("info") ArrayList<String>info, @RequestParam("day") String day) {
//		System.out.println(aCode+":"+uCode+":"+info.get(0)+":"+info.get(1)+":"+ day);
//		return "logIn";
//	}
	
}
