package one.schedule.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import one.services.share.Share;
import one.user.bean.ScheduleBean;
import one.user.bean.Search;
import one.user.bean.TDetails;
import one.user.bean.TeamBean;

@RestController
@RequestMapping("/schedule")
public class RestControllers {
	    // RestController >> 페이지 전체가 아닌 특정한 부분만 바꾸려고 할 때 사용
     	
	@Autowired
	Share share;
	
	
	
	@PostMapping("/teamList")
	public List<TeamBean> getTeamList(@RequestBody List<TeamBean> list) {
	
		return share.getTeamList(list.get(0));
	}
	
	@PostMapping("/memberList")
	public List<TDetails> getMemberList(@RequestBody List<TDetails> list2) {
		
	 
		return share.getMemberList(list2.get(0));
	}
	
	@PostMapping("/addTeam")
	public List<TeamBean> addTeamList(@RequestBody List<TeamBean> list) {
	
		return share.addTeam(list.get(0));
	}
	
	@PostMapping("/frList")
	public List<TDetails> frList(@RequestBody List<TDetails> list2) {
		
		return share.frList(list2.get(0));
	}
	
	@PostMapping("/sendMail")
	public List<TDetails> sendMail(@RequestBody List<TeamBean> tb) {
		//System.out.println(tb.get(0).getTdetails().size()+ "왔나요??");
	   
		return share.addMember(tb.get(0));
	}
	
	@PostMapping("/search")
	public List<Search> search(@RequestBody List<Search> sc) {
		//System.out.println(tb.get(0).getTdetails().size()+ "왔나요??");
             System.out.println(sc.get(0));
		return share.searchFr(sc.get(0));
	}
	
	@PostMapping("/sendMail2")
	public Map<String, String> sendMail2(@RequestBody List<TDetails> list2) {
		 
		
		return share.mail2(list2);
	}
	
	@PostMapping("/sendAddFr")
	public void sendFr(@RequestBody List<TDetails> list2) {
		 	
	share.insFr(list2);
	}
	
	@PostMapping("/clickYes")
	public void clickYes(@RequestBody List<TDetails> list2) {
		 	
		 	
	 share.upFr(list2.get(0));
	 
	 
	}
	
	@PostMapping("/clickNo")
	public void clickNo(@RequestBody List<TDetails> list2) {
	
		share.delFr(list2.get(0));
	
	}
	
	@PostMapping("/viewSd")
	public ModelAndView viewSd(@RequestBody List<ScheduleBean> list3) {
	System.out.println(list3);
		
		return  share.viewSd(list3.get(0));
	
	}
	
	
	
	
	

}
