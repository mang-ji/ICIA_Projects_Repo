package restaurant.services.pattern;

class DataAccessObject extends parents.pattern.DataAccessObject{
	
	DataAccessObject() {
		super();
	}
}
