package restaurant.services.pattern;

import javax.servlet.http.HttpServletRequest;

import beans.pattern.Action;

public class RestaurantServices {
	private HttpServletRequest req;
	
	public RestaurantServices(HttpServletRequest req) {
		this.req = req;
	}
	
	public Action rmainCtl() {
		Action action = null;
		DataAccessObject dao = new DataAccessObject();
		
		return action;
	}
	
}
