package user.services.pattern;

import java.sql.SQLException;
import java.util.ArrayList;

import beans.pattern.ReserveInfo;
import beans.pattern.RestaurantInfo;

class DataAccessObject extends parents.pattern.DataAccessObject {
	
	DataAccessObject() {
		super();
	}

	public ArrayList<RestaurantInfo> getSearchMenu(RestaurantInfo ri) {
		ArrayList<RestaurantInfo> list = new ArrayList<RestaurantInfo>();
		
		String query = "SELECT * FROM SEARCHMENU WHERE SWORD LIKE '%'||?||'%'";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getWord());
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				RestaurantInfo ri2 = new RestaurantInfo();
				ri2.setReCode(rs.getNString("RECODE"));
				ri2.setReName(rs.getNString("RESTAURANT"));
				ri2.setFcCode(rs.getNString("FCCODE"));
				ri2.setFcName(rs.getNString("FCNAME"));
				ri2.setMenuCode(rs.getNString("MENUCODE"));
				ri2.setMenu(rs.getNString("MENU"));
				ri2.setLcCode(rs.getNString("LCCODE"));
				ri2.setLocation(rs.getNString("LOCATION"));
				ri2.setPrice(rs.getInt("PRICE"));
				list.add(ri2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	 ArrayList<ReserveInfo> getDate(ReserveInfo ri) {
		ArrayList<ReserveInfo> list = new ArrayList<ReserveInfo>();
		
		String query = "SELECT  TO_CHAR(BL_DATE,'YYYYMMDD') as rDate FROM BL WHERE BL_RECODE = ? AND BL_STATE = ?";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getReCode());
			pstmt.setNString(2, ri.getProcess());
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ReserveInfo ri2 = new ReserveInfo();
				ri2.setRdate(rs.getNString("rDate"));
				list.add(ri2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return list;
	}

	public ArrayList<ReserveInfo> getMenu(ReserveInfo ri) {
		ArrayList<ReserveInfo> list = new ArrayList<ReserveInfo>();
		
		String query = "SELECT RESTAURANT,MENU,MENUCODE, PRICE FROM SEARCHMENU WHERE  RECODE = ?";
		
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getReCode());
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ReserveInfo ri2 = new ReserveInfo();
				ri2.setReCode(ri.getReCode());
				ri2.setReName(rs.getNString("RESTAURANT"));
				ri2.setMenuCode(rs.getNString("MENUCODE"));
				ri2.setMenu(rs.getNString("MENU"));
				ri2.setPrice(rs.getInt("PRICE"));
				list.add(ri2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return list;
	}

	public int insBooking(ReserveInfo ri) {
		int result = 0;
		String query = "INSERT INTO BL(BL_RECODE, BL_MMCODE, BL_DATE, BL_STATE)\r\n" + 
				"VALUES(?, ?, TO_DATE(?, 'YYYYMMDD'), 'B')";
		
//		System.out.println(ri.getReCode());
//		System.out.println(ri.getuCode());
//		System.out.println(ri.getRdate());		
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getReCode());
			pstmt.setNString(2, ri.getuCode());
			pstmt.setNString(3, ri.getRdate());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	public int insBDetail(String menuCode ,String quantity, ReserveInfo ri) {
		int result = 0;
		String query = "insert into bd(bd_blrecode,bd_blmmcode,bd_bldate,bd_mlcode,bd_qty) values(?,?,to_date(?,'yyyyMMdd'),?,?)";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getReCode());
			pstmt.setNString(2, ri.getuCode());
			pstmt.setNString(3, ri.getRdate());
			pstmt.setNString(4, menuCode);
			pstmt.setInt(5, Integer.parseInt(quantity));
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	public int insBookingUp(ReserveInfo ri) {
		
		int result = 0;
		
		String query = "update bl set bl_state = 'W' where bl_recode = ? and bl_mmcode = ? and bl_date = ?";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ri.getReCode());
			pstmt.setNString(2, ri.getuCode());
			pstmt.setNString(3, ri.getRdate());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ArrayList<ReserveInfo> getMypage(ReserveInfo ri) {
		ArrayList<ReserveInfo> list = new ArrayList<ReserveInfo>();
		String query = "SELECT  bl_recode as reCode, re_name as rName, bl_mmcode as uCode, bl_date as rDate, bl_state as process\r\n" + 
				"				FROM BL inner join re on bl_recode = re_code\r\n" + 
				"				WHERE BL_MMCODE = ? ";
		
		
		try {
			pstmt =connection.prepareStatement(query);
			pstmt.setNString(1, ri.getuCode());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ReserveInfo bean = new ReserveInfo();
				bean.setReName(rs.getNString("rName"));
				bean.setRdate(rs.getNString("rDate"));
				bean.setProcess(rs.getNString("process"));
				list.add(bean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	
}
