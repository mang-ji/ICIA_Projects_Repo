package user.services.pattern;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import beans.pattern.Action;
import beans.pattern.ReserveInfo;
import beans.pattern.RestaurantInfo;


public class UserServices {
	private HttpServletRequest req;
	private DataAccessObject dao;
	private Action action;
	private HttpSession session;
	
	public UserServices(HttpServletRequest req) {
		this.req = req;
	}

	public Action searchCtl() {
		action = new Action();
		dao = new DataAccessObject();
		RestaurantInfo ri = new RestaurantInfo();
		ri.setWord(req.getParameter("word"));
		dao.dbOpen(3);

		req.setAttribute("list",this.searchMenuHtml(this.getSearchMenu(dao, ri)));
		action.setPage("search.jsp");
		action.setRedirect(false);

		dao.dbClose();
		return action;
	}

	private ArrayList<RestaurantInfo> getSearchMenu(DataAccessObject dao,RestaurantInfo ri){
		return this.dao.getSearchMenu(ri);
	}

	private String searchMenuHtml(ArrayList<RestaurantInfo> list) {
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		sb.append("<tr><th>레스토랑</th><th>분류</th><th>위치</th><th>메뉴</th><th>가격</th></tr>");
		for(RestaurantInfo ri : list) {
			sb.append("<tr onClick=\'reserve()\'>");
			sb.append("<td>" + ri.getReName() + "<input type=\'hidden\' name=\'reCode\' value=\'"+ ri.getReCode() +"\'</td>");
			sb.append("<td>" + ri.getFcName() + "</td>");
			sb.append("<td>" + ri.getLocation() + "</td>");
			sb.append("<td>" + ri.getMenu() + "</td>");
			sb.append("<td>" + ri.getPrice() + "</td>");
			sb.append("</tr>");
		}
		sb.append("</table>");

		return sb.toString(); 
	}

	public Action dateCtl() {
		dao = new DataAccessObject();
		action = new Action();
		//ArrayList<String> test;
		ReserveInfo ri = new ReserveInfo();
		ri.setReCode(req.getParameter("reCode"));
		ri.setProcess("C");
		action.setPage("date.jsp");
		action.setRedirect(false);
		dao.dbOpen(3);
		req.setAttribute("date",makeDateHtml(compareDate(this.getDate(dao,ri),this.dupDate()),ri));
		//		for(int i = 0; i < test.size(); i++) {
		//			System.out.println(test.get(i));
		//		}
		dao.dbClose();
		return action;
	}

	private ArrayList<ReserveInfo> getDate(DataAccessObject dao,ReserveInfo ri){
		return dao.getDate(ri);
	}

	private ArrayList<String> dupDate(){
		ArrayList<String> date = new ArrayList<String>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar = Calendar.getInstance();
		for(int i =1;i<=7;i++) {
			calendar.add(Calendar.DAY_OF_MONTH, +1);
			date.add(sdf.format(calendar.getTime()));
			
		}
		return date;
	}
	private ArrayList<String> compareDate(ArrayList<ReserveInfo> list, ArrayList<String> dup){

		if(list.size()>0) {
			for(int i = dup.size()-1 ;i>=0;i--) {
				for(int j=0;j<list.size() ;j++) {
					if(dup.get(i).equals(list.get(j).getRdate())) {
						dup.remove(i);
						break;
					}
				}
			}
		}
		return dup;
	}

	private String makeDateHtml(ArrayList<String> date, ReserveInfo ri) {
		StringBuffer sb = new StringBuffer();

		int index= 0;
		for(String list : date) {
			sb.append("<div onClick='getMenu("+index+")'>");
			sb.append(list);
			sb.append("<input type='hidden' name='reCode' value = \'"+ri.getReCode()+"\' >");
			sb.append("<input type='hidden' name='rDate' value = \'"+list+"\' >");
			sb.append("</div>");
			index++;
		}


		return sb.toString();
	}

	public Action menuCtl() {
		action = new Action();
		dao = new DataAccessObject();
		ReserveInfo ri = new ReserveInfo();
		HttpSession session = req.getSession();
		ri.setuCode((String)session.getAttribute("user"));
		ri.setReCode(req.getParameter("reCode"));
		ri.setRdate(req.getParameter("rDate"));
		dao.dbOpen(3);
		dao.setTranConf(false);
		req.setAttribute("menu",makeMenuHtml(dao.getMenu(ri),ri.getRdate()));
		action.setPage("menu.jsp");		
		action.setRedirect(false);
		dao.insBooking(ri);
		dao.setTran(true);
		dao.dbClose();
		return action;
	}

	private String makeMenuHtml(ArrayList<ReserveInfo> list,String rDate) {
	      StringBuffer sb = new StringBuffer();
	      sb.append("<div class= \'mtitle\'>YAHOON!</div>");
	      sb.append("<div id=  \'store_title\'>");
	      sb.append("[ "+list.get(0).getReName()+ " ]");
	      sb.append("</div>");
	      sb.append("<div class=\"menuTable_box\">");
	      sb.append("<table class=\"menuTable\"  >");
	      for(ReserveInfo bean :list) {
	         sb.append("<tr class=\"tr_menu\"> ");
	         sb.append("<td> 이미지 </td>");
	         sb.append("<td>"+ bean.getMenu()+"       "+bean.getPrice() +"</td>");
	         sb.append("<td> 수량&nbsp; <input type = \'number\' name = 'quantity' value = \'0\' min = \'1\' max = \'10\'> </td>");
	         sb.append("</tr>");
	         sb.append("<input type='hidden' name='reCode' value =\'"+bean.getReCode()+"\'>");
	         sb.append("<input type='hidden' name='reName' value =\'"+bean.getReName()+"\'>");
	         sb.append("<input type='hidden' name='rDate' value =\'"+rDate+"\'>");
	         sb.append("<input type='hidden' name='menu' value =\'"+bean.getMenu()+"\'>");
	         sb.append("<input type='hidden' name='menuCode' value =\'"+bean.getMenuCode()+"\'>");
	         sb.append("<input type='hidden' name='price' value =\'"+bean.getPrice()+"\'>");
	      }
	      sb.append("</table>");
	      sb.append("</div>");

	      return sb.toString();
	   }

	public Action reserveCtl() {
		action = new Action();
		dao = new DataAccessObject();
		String[] reCode = req.getParameterValues("reCode");//
		String[] reName = req.getParameterValues("reName");//
		String[] rDate = req.getParameterValues("rDate");//
		String[] menu = req.getParameterValues("menu");
		String[] menuCode = req.getParameterValues("menuCode");
		String[] price = req.getParameterValues("price");
		String[] quantity = req.getParameterValues("quantity");
		
		ReserveInfo ri = new ReserveInfo();
		ArrayList<String> list = new ArrayList<String>();
		HttpSession session = req.getSession();
		ri.setuCode((String)session.getAttribute("user"));
		
//		for(int index=reCode.length-1; index >= 0; index--) {
//			System.out.println(reCode[index] + " " + reName[index] + " " + rDate[index]+ " " + menu[index]+ " " + menuCode[index]+ " " + price[index]+ " " + quantity[index]);
//		}
	
		// reCode , uCode , rdate , menuCode , quantity
		
		ri.setReCode(req.getParameterValues("reCode")[0]);
		ri.setReName(req.getParameterValues("reName")[0]);
		ri.setRdate(req.getParameterValues("rDate")[0]);
		for(int i=0; i < menu.length; i++) {
			list.add(req.getParameterValues("menu")[i]);
			list.add(req.getParameterValues("menuCode")[i]);
			list.add(req.getParameterValues("quantity")[i]);
		}
		
		req.setAttribute("reserve", makeReserveHtml());
		dao.dbOpen(3);
		
		for(int i=0; i < menu.length; i++) {
			// 메뉴코드랑 수량
			dao.insBDetail(menuCode[i],quantity[i],ri);
			System.out.println(menuCode[i]+quantity[i]);
		}
		dao.insBookingUp(ri); 
		
		dao.dbClose();
		action.setPage("reserve.jsp");
		action.setRedirect(false);
		
		return action;
	}
	
	private String makeReserveHtml() {
		String[] reCode = req.getParameterValues("reCode");
		String[] reName = req.getParameterValues("reName");
		String[] rDate = req.getParameterValues("rDate");
		String[] menu = req.getParameterValues("menu");
		String[] menuCode = req.getParameterValues("menuCode");
		String[] price = req.getParameterValues("price");
		String[] quantity = req.getParameterValues("quantity");
		StringBuffer sb = new StringBuffer();
		sb.append("<div class = \'mbox\'>");
		for(int index=reCode.length-1; index >= 0; index--) {
		
			sb.append("<div class = \'mbox2\'>");
			sb.append("<div  class = \'mlist2\'>"+reName[index]+"</div>");
			sb.append("<div  class = \'mlist2\'>"+menu[index]+"</div>");
			sb.append("<div  class = \'mlist2\'> "+price[index]+"</div>");
			sb.append("<div  class = \'mlist2\'>"+quantity[index]+"</div>");
			sb.append("<div  class = \'mlist2\'>"+rDate[index]+"</div>");
	
		    sb.append("</div>");
			
		}
		sb.append("</div>");
		return sb.toString();
	}

	public Action mypageCtl() {
		action = new Action();
		dao = new DataAccessObject();
		ReserveInfo ri = new ReserveInfo();
		HttpSession session = req.getSession();
		ri.setuCode((String)session.getAttribute("user"));
		
		dao.dbOpen(3);
		
		System.out.println(ri.getuCode());
		
		req.setAttribute("myPage", makeMypageHtml(dao.getMypage(ri)));
		dao.dbClose();
		
		action.setPage("mypage.jsp");
		action.setRedirect(false);
		return action;
	}
	// the end >< hehe  the end the end jessi je
	public String makeMypageHtml(ArrayList<ReserveInfo> list) {
		StringBuffer sb = new StringBuffer();
		
		for(ReserveInfo ri : list) {
			if(ri.getProcess().equals("W")) {
				sb.append("<div>");
				sb.append(ri.getReName() + " " + ri.getRdate() + " " + "예약대기");
				sb.append("</div>");
			}
			
		}
		
		return sb.toString();
	}

	
}
