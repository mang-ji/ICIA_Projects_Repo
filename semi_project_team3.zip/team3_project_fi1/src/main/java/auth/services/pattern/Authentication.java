package auth.services.pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import beans.pattern.AccessBean;
import beans.pattern.Action;

public class Authentication {
	private HttpServletRequest req;
	private HttpSession session;
	public Authentication(HttpServletRequest req) {
		this.req = req;
	}
	
	public Action logInCtl() {
		Action action = new Action();
		DataAccessObject dao = new DataAccessObject();
		AccessBean ab = new AccessBean();
		ab.setUserType("G");
		ab.setUserId(req.getParameter("uCode"));
		ab.setUserPassword(req.getParameter("aCode"));
		dao.dbOpen(3); 
		
//		action.setPage("access.jsp");
//		action.setRedirect(false);
		
		if(isIdCheck(dao,ab)) {
			if(isAccessCheck(dao, ab)) {
				action.setPage("search.jsp");
				action.setRedirect(false);
				session = req.getSession();
				session.setAttribute("user", ab.getUserId());
			}
		}
		
		dao.dbClose();
		return action;
	}
	
	public Action joinCtl() {
		Action action = new Action();
		DataAccessObject dao = new DataAccessObject();
		AccessBean ab = new AccessBean();
		boolean tran = false;
		
		ab.setUserId(req.getParameter("uCode"));
		ab.setUserPassword(req.getParameter("aCode"));
		ab.setUserName(req.getParameter("uName"));
		ab.setUserEtc(req.getParameter("location"));
		
		
		
		dao.dbOpen(3); dao.setTranConf(false);
		if(convertToBoolean(dao.insUserJoin(ab))) {
			action.setPage("access.jsp");
			action.setRedirect(false);
			tran = true;
		}else {
			action.setPage("join.jsp");
			action.setRedirect(true);
		}
		dao.dbClose(); dao.setTran(tran);
		
		
		
		return action;
	}
	
	public Action dupCtl() {
		Action action = new Action();
		DataAccessObject dao = new DataAccessObject();
		AccessBean ab = new AccessBean();
		String message ="사용이 가능한 아이디입니다.";
		
		ab.setUserId(req.getParameter("uCode"));
		ab.setUserType("G");
		dao.dbOpen(3);
		if(this.idDupCheck(dao,ab)) {
		     message="사용이 불가능한 아이디입니다.";
		}
		req.setAttribute("uCode", ab.getUserId());
		req.setAttribute("message", message);
		dao.dbClose();
		 action.setPage("join.jsp");
		 action.setRedirect(false);
		
		return action;
	}
	
	private boolean isIdCheck(DataAccessObject dao, AccessBean ab) {
		return this.convertToBoolean(ab.getUserType().equals("G")? dao.isUserIdCheck(ab) : dao.isReCodeCheck(ab));
	}
		
	private boolean isAccessCheck(DataAccessObject dao, AccessBean ab) {
		return this.convertToBoolean(ab.getUserType().equals("G")? dao.isUserAccessCheck(ab): dao.isReAccessCheck(ab));
	}
	
	private boolean insJoin(DataAccessObject dao, AccessBean ab) {
		return this.convertToBoolean(ab.getUserType().equals("G")? dao.insUserJoin(ab): dao.insReJoin(ab));
	}
	
	private boolean idDupCheck(DataAccessObject dao, AccessBean ab) {
		
		return this.convertToBoolean(ab.getUserType().equals("G")? dao.dupCheck(ab):0);
	}
	private boolean convertToBoolean(int value) {
		return (value > 0)? true: false;
	}


}
