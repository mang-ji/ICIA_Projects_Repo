package auth.services.pattern;

import java.sql.SQLException;

import beans.pattern.AccessBean;

class DataAccessObject extends parents.pattern.DataAccessObject {
	
	DataAccessObject() {
		super();
	}
	
	
	int isUserIdCheck(AccessBean ab) {
		int result=0;
		String query = "select count(*) as result from mm where mm_code=?";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ab.getUserId());
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt("result");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}
	
	int isReCodeCheck(AccessBean ab) {
		
		return 0;
	}
	
	int isUserAccessCheck(AccessBean ab) {
		int result=0;
		String query = "select count(*) as result from mm where mm_code=? AND mm_password=?";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ab.getUserId());
			pstmt.setNString(2, ab.getUserPassword());
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt("result");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}
	int isReAccessCheck(AccessBean ab) {
		
		return 0;
	}
	
	int insAuthHistory(AccessBean ab) {
		
		return 0;
	}
	
	int dupCheck(AccessBean ab) {
		int result = 0;
		String query = "SELECT COUNT(*) AS COUNT FROM MM WHERE MM_CODE = ?";
		 
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ab.getUserId());
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt("COUNT");
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		
		
		return result;
	}
	
	int insUserJoin(AccessBean ab) {
		int result = 0;
		
		String query ="INSERT INTO MM(MM_CODE, MM_PASSWORD, MM_NAME , MM_LCCODE)\r\n"
				+ "VALUES(?,?,?,?)";
		
		try {
			pstmt = connection.prepareStatement(query);
			pstmt.setNString(1, ab.getUserId());
			pstmt.setNString(2, ab.getUserPassword());
			pstmt.setNString(3, ab.getUserName());
			pstmt.setNString(4, ab.getUserEtc());
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	int insReJoin(AccessBean ab) {
		
		return result;
	}
}
