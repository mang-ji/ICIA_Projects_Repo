package beans.pattern;

public class RestaurantInfo {

	private String word;
	private String reCode;
	private String reName;
	private String menu;
	private String menuCode;
	private int price;
	private String lcCode;
	private String location;
	private String fcCode;
	private String fcName;
	
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getReCode() {
		return reCode;
	}
	public void setReCode(String reCode) {
		this.reCode = reCode;
	}
	public String getReName() {
		return reName;
	}
	public void setReName(String reName) {
		this.reName = reName;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getMenuCode() {
		return menuCode;
	}
	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getLcCode() {
		return lcCode;
	}
	public void setLcCode(String lcCode) {
		this.lcCode = lcCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFcCode() {
		return fcCode;
	}
	public void setFcCode(String fcCode) {
		this.fcCode = fcCode;
	}
	public String getFcName() {
		return fcName;
	}
	public void setFcName(String fcName) {
		this.fcName = fcName;
	}
	
	
}
