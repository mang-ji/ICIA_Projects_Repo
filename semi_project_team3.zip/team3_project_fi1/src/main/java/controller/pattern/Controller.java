package controller.pattern;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.services.pattern.Authentication;
import beans.pattern.Action;
import restaurant.services.pattern.RestaurantServices;
import user.services.pattern.UserServices;

@WebServlet({"/LogInForm", "/JoinForm", "/LogIn", "/Join","/Rmain","/SearchMenu","/getDate","/getMenu","/sendReserve","/myPage" , "/DupCheck"})
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Controller() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		// LogInForm, JoinForm
		String jobCode = request.getRequestURI().substring(request.getContextPath().length()+1);
		String page;
		UserServices us = null;
		Action action = null;
		
		switch(jobCode) {
		case "LogInForm":
			action.setPage("access.jsp");
			action.setRedirect(true);
			break;
		case "JoinForm":
			action.setPage("join.jsp");
			action.setRedirect(true);
			break;
		case "SearchMenu":
			us = new UserServices(request);
			action = us.searchCtl();
			break;
		default:
			action.setPage("warnning.jsp");
			action.setRedirect(true);
		}
		
		if(action.isRedirect() == true) {
			response.sendRedirect(action.getPage());
		}else {
			RequestDispatcher rd = request.getRequestDispatcher(action.getPage());
			rd.forward(request, response);
		}		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		// LogIn, Join
		String jobCode = request.getRequestURI().substring(request.getContextPath().length()+1);
		Authentication auth = null;
		UserServices us = null;
		RestaurantServices rs = null;
		Action action = null;
		
		if(jobCode.equals("LogIn")) {
			auth = new Authentication(request);
			action = auth.logInCtl();
		}else if(jobCode.equals("Join")) {
			auth = new Authentication(request);
			action = auth.joinCtl();
		}else if(jobCode.equals("Rmain")) {
			rs = new RestaurantServices(request);
			action = rs.rmainCtl();
		}else if(jobCode.equals("LogInForm")) {
			action = new Action();
			action.setPage("access.jsp");
			action.setRedirect(true);
		}else if(jobCode.equals("JoinForm")) {
			action = new Action();
			action.setPage("join.jsp");
			action.setRedirect(true);
		}else if(jobCode.equals("getDate")) {
			us = new UserServices(request);
			action = us.dateCtl();
		}else if(jobCode.equals("getMenu")) {
			us = new UserServices(request);
			action = us.menuCtl();
		}else if(jobCode.equals("sendReserve")) {
			us = new UserServices(request);
			action = us.reserveCtl();
		}else if(jobCode.equals("myPage")) {
			us = new UserServices(request);
			action = us.mypageCtl();
		}else if(jobCode.equals("DupCheck")) {
			auth = new Authentication(request);
			action = auth.dupCtl();
		}else {
			
		}
		
		
		if(action.isRedirect() == true) {
			response.sendRedirect(action.getPage());
		}else {
			RequestDispatcher rd = request.getRequestDispatcher(action.getPage());
			rd.forward(request, response);
		}
		
	}

}
