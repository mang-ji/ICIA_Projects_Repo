function callType(object){
	// Click된 Div의 선택(색상 바꾸기):: default: #F6F6F6 << bg >> #FFBB00
	// general  restaurant
	let accessType = document.getElementsByName("accessType")[0];
	let objectId;
	if(object.id == "general"){
		objectId = "restaurant";
		accessType.value = "G";
	}else{
		objectId = "general";
		accessType.value = "R";
	}
	
	object.className = "choiceOn";
	document.getElementById(objectId).className = "choiceOff";

}

/* 회원가입 유형에 따른 CSS */
function joinType(object){
	let accessType = document.getElementsByName("accessType")[0];
	
	let objectId;
	if(object.id == "general"){
		objectId = "restaurant";
		accessType.value = "G";
		
		uCode.innerText = "User Code";
		//uCode.placeholder = "Your ID";
		uName.innerText = "User Name";
		//uName.placeholder = "Your Name";	
		uEtc.innerText = "User Phone";
		//uEtc.placeholder = "Your Phone";
		
		sel.style.display = "none";
	}else{
		objectId = "general";
		accessType.value = "R";
		// innerHtml | innerText
		uCode.innerText = "Restaurant Code";
		//uCode.placeholder = "레스토랑 코드";
		uName.innerText = "Restaurant Name";
		//uName.placeholder = "상호명";	
		uEtc.innerText = "CEO Name";
		//uEtc.placeholder = "대표자";
		
		sel.style.display = "block";			
	}
	
	object.className = "choiceOn";
	document.getElementById(objectId).className = "choiceOff";
}

function isIdCheck(word, type){
	const cuComp = /^[A-Z]{1}[A-Z0-9]{4,9}$/;
	const reComp = /^[0-9]{10}$/;
	let result;

	if(type){
		result = cuComp.test(word);
	}else{
		result = reComp.test(word);
	}
	
	return result;
}

function isPasswordCheck(word){
	const sEng = /[a-z]/;
	const bEng = /[A-Z]/;
	const num = /[0-9]/;
	const special = /[!@#$%^&*]/; 
	
	// password가 영문소문자, 영문대문자, 숫자, 특수문자 중 3가지 이상의 문자군을 사용했는지 여부
	let count = 0;
	if(sEng.test(word)){	count++; }
	if(bEng.test(word)){	count++; }
	if(num.test(word)){	count++; }	
	if(special.test(word)){	count++; }
	
	return count;
}

function charCount(word, min, max){
	return word.length >= min && word.length <= max;
}

function korCheck(obj, event){
	const pattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
	
	if(pattern.test(event.target.value.trim())) {
		obj.value = obj.value.replace(pattern,'').trim();
	}
}

function sendLogInInfo(){
	var uCode = document.getElementsByName("uCode")[0];
	var aCode = document.getElementsByName("aCode")[0];
	
	f = document.createElement("form");
	f.method = "post";
	f.action = "LogIn";
	
	f.appendChild(uCode);
	f.appendChild(aCode);
	document.body.appendChild(f);
	f.submit();
}


function enter(){
	if(event.keyCode == 13){
		let word = document.getElementsByName("word")[0];
		let f = document.createElement("form");
		
		f.action = "SearchMenu";
		f.method = "get";
		f.appendChild(word);
		document.body.appendChild(f);
		f.submit();
	}
}

function reserve(){
	let reCode  = document.getElementsByName("reCode")[0];
	
	let f = document.createElement("form");
	f.action = "getDate";
	f.method = "post";
	
	f.appendChild(reCode);
	document.body.appendChild(f);
	f.submit();
}

function getMenu(index){
	let reCode = document.getElementsByName("reCode")[0];
	let rDate = document.getElementsByName("rDate")[index];
	
	let f = document.createElement("form");
	
	f.action = "getMenu";
	f.method = "post";
	
	f.appendChild(reCode);
	f.appendChild(rDate);
	
	document.body.appendChild(f);
	f.submit();
}


function selectMenu(){
	let reCode = document.getElementsByName("reCode");
	let reName = document.getElementsByName("reName");
	let rDate = document.getElementsByName("rDate");
	let menu = document.getElementsByName("menu");
	let menuCode = document.getElementsByName("menuCode");
	let price = document.getElementsByName("price");
	let quantity = document.getElementsByName("quantity");
	  
	let f = document.createElement("form");
	
	f.action = "sendReserve";
	f.method = "post";
	
	for(index=reCode.length-1; index >= 0; index--){
		if(quantity[index].value!=0){
			f.appendChild(reCode[index]);
			f.appendChild(reName[index]);
			f.appendChild(rDate[index]);
			f.appendChild(menu[index]);
			f.appendChild(menuCode[index]);
			f.appendChild(price[index]);
			f.appendChild(quantity[index]);
		}
	}
	
	document.body.appendChild(f);
	f.submit();
	
}

function reserveCheck(){
	
	let f = document.createElement("form");
	
	f.action = "myPage";
	f.method = "post";
	
	document.body.appendChild(f);
	f.submit();
	
}

function dupCheck(){
	let uCode = document.getElementsByName("uCode")[0];
	let dupBtn = document.getElementById("duplicate");
	let f = document.createElement("form");
	
	
	
	if(isIdCheck(uCode.value, true)){
	if(dupBtn.innerText.includes("중복검사")){
		f.action = "DupCheck";
	    f.method = "post";
	
	    f.appendChild(uCode);
	 
	    document.body.appendChild(f);
	
	    f.submit();
	}else{
		
		dupBtn.innerText = "중복검사";
		uCode.readOnly = false;
		uCode.value = "";
		
	}
	}else{
		alert("아이디 형식에 맞지 않습니다.");
		uCode.value="";
		uCode.focus();
	}
	
	}
	

function message(message,userId){
   let uCode = document.getElementsByName("uCode")[0];
   let dupBtn = document.getElementById("duplicate");
   
   
   if(message != ''){
      alert(message);
      if(message.includes("불가능")){
         uCode.value="";
         uCode.focus();
      }else{
	     result = confirm(message + "사용하시겠습니까?");
         if(result){
         uCode.value = userId;
         uCode.readOnly = true;
         dupBtn.innerText = "재입력";                                                                                                         
      }
}
   }
}

function sendJoinInfo(){
	
	let uCode = document.getElementsByName("uCode")[0];
	let aCode = document.getElementsByName("aCode");
	let userName = document.getElementsByName("uName")[0];
	let location = document.getElementsByName("location")[0];
	
	let f = document.createElement("form");
	
	if(isPasswordCheck(aCode[0].value) >=3){
	if(charCount(aCode[0].value,4,9)){
    if(aCode[0].value == aCode[1].value){
	f.action= "Join";
	f.method = "post";
	
	f.appendChild(uCode);
	f.appendChild(aCode[0]);
	f.appendChild(userName);
	f.appendChild(location);
	
	document.body.appendChild(f);
	
	f.submit();

		
	}else{
		alert("비밀번호 형식에 맞지 않습니다.");
		aCode[0].value = "";
		aCode[1].value = "";
		aCode[0].focus();
	
		
	}
	}
	}
	
	
	
	
}
	
	

