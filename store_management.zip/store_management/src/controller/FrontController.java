package controller;

import model.Service;

public class FrontController {
	Service service;

	public FrontController() {

	}

	public String entrance(int serviceCode, String[]cData) {
         String result=null;
		switch(serviceCode) {
		case 1:
			service = new Service();
			result = service.entrance(serviceCode, cData);
			break;

		case 2 :
			service = new Service();
			result = service.entrance(serviceCode, cData);
			break;
			
		case 3 :
			service = new Service();
			result = service.entrance(serviceCode, cData);
			break;
			
		case 4 :
			service = new Service();
			service.entrance(serviceCode, cData);
			
		}
		return result;


	}
}
