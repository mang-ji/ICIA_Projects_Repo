package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

class DataAccessObject {
	private FileReader reader;
	private BufferedReader bReader;
	private FileWriter writer;
	private BufferedWriter bWriter;

	private String[] fileInfo = {"C:\\F\\Data\\Menu.txt",
			"C:\\F\\Data\\Restaurant.txt",
	"C:\\F\\Data\\Order.txt"};
	public DataAccessObject() {	
	}


	private void fileReading (int fileIndex) {

		try {
			reader = new FileReader(fileInfo[fileIndex]);
			bReader = new BufferedReader(reader);
		} catch (FileNotFoundException e) { e.printStackTrace(); }

	}
	private void readerClose() {
		if(bReader !=null) {
			try {
				bReader.close();
			} catch (IOException e) { e.printStackTrace(); }
		}
	}

	String [][] getFullData(){
		String[][] fullData = null;
		StringBuffer sb = new StringBuffer();
		String line;
		int count = 0;
		this.fileReading(2);

		try {
			while((line = bReader.readLine()) != null) {
				count++;
				sb.append(count ==1? line: ":" + line);

			}
			this.readerClose();
			
			String[]recordData=sb.toString().split(":");
			fullData = new String[recordData.length][];
			for(int record=0; record<recordData.length; record++) {
				fullData[record] = recordData[record].split(",");
			}
		} catch (IOException e) {e.printStackTrace();}

		return fullData;
	}


	private void fileWrite(int fileIndex, boolean overWrite) {

		try {
			writer = new FileWriter(fileInfo[fileIndex], overWrite);
			bWriter = new BufferedWriter(writer);
		} catch (IOException e) {e.printStackTrace();}
	}
	private void writerClose() {
		if(bWriter != null) {
			try {
				bWriter.close();
			} catch (IOException e) {e.printStackTrace(); }
		}
	}

	void setReserve(String[][] fullData) {
		int count =0;
		StringBuffer sb = new StringBuffer();
		this.fileWrite(2, false);
		for(String[] record : fullData) {
			for(String line :record) {
				count ++;
				sb.append(count ==1? line: "," +line);
			}	
			try {
				bWriter.write(sb.toString());
				bWriter.newLine();
				count =0;
				sb.delete(0, sb.length());
			} catch (IOException e) {e.printStackTrace();}
		}
		this.writerClose();
	}
	
	
	boolean isAccess(String []cData) {
		boolean result = false;
		String line = null;
		this.fileReading(1);

		try {
			while((line = bReader.readLine()) != null) {
				String [] lineData = line.split(",");
				if(lineData[0].equals(cData[0])) {
					if(lineData[3].equals(cData[1])) {
						result = true;
						break;
					}

				}

			}

		} catch (IOException e) {e.printStackTrace();}
		this.readerClose();

		return result;

	}

	String getStore(String storeCode) {
		String line = null;
		String result = null;
		this.fileReading(1);

		try {

			while((line = bReader.readLine()) != null) {
				String [] lineData = line.split(","); //�뒪�뵆由� �빐以� 媛믪쓣 lineData�뿉 �떞�뒗�떎.
				if(lineData[0].equals(storeCode)) { // lineData[0]�� �긽�젏肄붾뱶怨�, storeCode�뒗 �궗�슜�옄媛� �엯�젰�븳 媛�
					result = lineData[1]; // lineData[1]�� �긽�샇紐�
					break;
				}
			}
		} catch (IOException e) {e.printStackTrace();}

		this.readerClose();

		return result;
	}

	int getReserve(String storeCode) {
		StringBuffer sb = new StringBuffer();
		String[]records = null;
		String line;
		int count = 0; 
		this.fileReading(2);

		try {
			while((line = bReader.readLine()) != null) {
				if(line.substring(0,line.indexOf(",")).equals(storeCode)) {
					if(line.substring(line.lastIndexOf(",")+1).equals("n")) {
						count++;
						sb.append((count ==1)? line : ":" + line);
					}
				}
			}this.readerClose();

			records = sb.toString().split(":");
			count =0;
			for(int record = 0; record<records.length; record++) {
				for(int index = record+1; index<records.length; index++) {
					String root = records[record].substring(0, records[record].indexOf(",",
							records[record].indexOf(",",
									records[record].indexOf(",")+1)+1));
					String compare = records[index].substring(0,records[index].indexOf(",",
							records[index].indexOf(",",
									records[index].indexOf(",")+1)+1));
					if(root.contains(compare)) {
						count++; break;
					}
				}
			}
		} catch (IOException e) {e.printStackTrace();}

		return records.length - count;
	}

	String getReserveList(String storeCode) {
		int count = 0;
		StringBuffer  sb = new StringBuffer();
		String line;
		String[] records = null;
		this.fileReading(2);
		try {
			while((line = bReader.readLine()) !=null) {
				if(line.substring(0, line.indexOf(",")).equals(storeCode)) {
					if(line.substring(line.lastIndexOf(",")+1).equals("n")) {
						count++;
						sb.append((count == 1)? line: ":"+line);
					}
				}
			}
			this.readerClose();

			records = sb.toString().split(":");
			/* StringBuffer 珥덇린�솕 */
			sb.delete(0, sb.length());
			count = 0;
			for(int record=0; record<records.length; record++) {
				count++;
				String root = records[record].substring(0, 
						records[record].indexOf(",", 
								records[record].indexOf(",", 
										records[record].indexOf(",")+1)+1));
				/* records�쓽 泥ル쾲吏� �젅肄붾뱶�뒗 臾댁“嫄� ���옣 */
				if(record==0) {
					sb.append(root);
					sb.append("," + getDuplicateCount(records,root));
				}
				for(int index=record+1; index<records.length; index++) {
					String compare = records[index].substring(0, 
							records[index].indexOf(",", 
									records[index].indexOf(",", 
											records[index].indexOf(",")+1)+1));
					if(!root.equals(compare)) {
						if(!sb.toString().contains(compare)) {
							sb.append(":"+compare);
							sb.append(","+getDuplicateCount(records, compare));
						}
					}
				}
			}
		} catch (IOException e) {	e.printStackTrace();}	
		return sb.toString();
	}

	int getDuplicateCount(String [] data, String compare) {
		int count = 0;
		for(String record : data) {
			if(record.contains(compare)) {count++;}

		}
		return count;

	}

	int getToRes(String storeCode, String toDay) {
		StringBuffer sb = new StringBuffer();
		String line = null;
		int count = 0;
		this.fileReading(2);

		try {
			while((line = bReader.readLine()) != null) {
				String[] lineData = line.split(",");
				if(lineData[0].equals(storeCode)) {
					if(lineData[2].equals(toDay)) {
						if(lineData[6].equals("y")) {
							count++;
						}
					}
				}
			}

		} catch (IOException e) {e.printStackTrace();}

		this.readerClose();


		return count;
	}
	String getToResList (String storeCode, String toDay) {
		StringBuffer sb = new StringBuffer();
		String line = null;
		int count = 0;
		this.fileReading(2);

		try {
			while((line = bReader.readLine()) != null) {
				String[] lineData = line.split(",");
				if(lineData[0].equals(storeCode)) {
					if(lineData[2].equals(toDay)) {
						if(lineData[6].equals("y")) {
							count++;
							sb.append(count ==1? line : ":" + line);
						}
					}
				}
			}

		} catch (IOException e) {e.printStackTrace();}

		this.readerClose();

		return sb.toString();
	}



	void allFileReading () {



	}






}
