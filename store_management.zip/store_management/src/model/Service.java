package model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Service {
	DataAccessObject dao;
	StringBuffer reserveList = new StringBuffer();

	public Service() {


	}

	public String entrance(int serviceCode, String[]cData) {
		String result ="";
		switch (serviceCode){
		case 1 : 
			result = this.logInCtl(cData);
			break;

		case 2:
			result = this.getReserveList(cData);
			break;

		case 3 : 
			result = this.getToResList(cData, this.getToday());
			break;
          
		case 4 :
			result = this.setReserveConfirm(cData);
			break;
		default:
		}
		return result;

	}

	
	private String getReserveList(String[] cData) {
		dao = new DataAccessObject();
		return dao.getReserveList(cData[0]);
	}

	private String getToResList(String[] cData, String toDay) {
		dao = new DataAccessObject();
		return dao.getToResList(cData[0], toDay);
	}


	private String logInCtl(String [] cData) {
		dao = new DataAccessObject();
		StringBuffer result = new StringBuffer();
		if(this.isAccess(cData)) {
			result = new StringBuffer();
			result.append(this.getStore(cData[0]));
			result.append(":"+this.getReserve(cData[0]));
			result.append(":"+this.getToRes(cData[0],getToday()));

		}
		return result.toString();
	}

	private boolean isAccess(String []cData) {
		return dao.isAccess(cData);
	}

	private String getStore(String storeCode) {
		return dao.getStore(storeCode);

	}

	private int getReserve(String storeCode) {
		return dao.getReserve(storeCode);
	}

	private int getToRes(String storeCode, String toDay) {
		return dao.getToRes(storeCode, toDay);
	}
	
	private String getToday() {
		Date toDay = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		return sdf.format(toDay);

	}
	
	private String setReserveConfirm(String[]cData) {
		dao = new DataAccessObject();
		String [][] fullData = dao.getFullData();

		for(int record = 0; record<cData.length; record++) {
			String[] line = cData[record].split(",");
			for(int index = 0; index<fullData.length; index++) {
				if(line[0].equals(fullData[index][0])) {
					if(line[1].equals(fullData[index][1])) {
						if(line[2].equals(fullData[index][2])) {
							if(fullData[index][fullData[index].length-1].equals("n")) {
								fullData[index][fullData[index].length-1] = "y";
							}
						}
					}
				}
			}
		}
		dao.setReserve(fullData);
		return null;
		
	}


}
