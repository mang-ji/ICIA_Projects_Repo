package view;

import java.util.Scanner;

import controller.FrontController;

public class View {
	FrontController fc;
	Scanner scanner = new Scanner(System.in);

	public View() {
		this.entrance();

	}

	private void entrance() {

		String title;
		String[] accessInfo;
		title = setTitle();
		String response ="";

		String store = (response.split(":")[0]);
		while(true) {
			accessInfo = Step1(title);
			if(userInput("________________________ Confirm(y/n) : ").equals("y")) {
				break;

			}

			response = "명동찌개 : 0 : 2";
			if(Integer.parseInt(response.split(":")[1])!=-1){
				break;
			}

		}
		System.out.print(this.Step2(title, response));



	}



	private String[] Step1(String title) {
		String [] accessInfo = new String[2];
		this.display(title);
		this.display(" \n [ Certification ]_____________________\n\n");
		accessInfo[0] = userInput(" [  Store Code  ] : ");
		accessInfo[1] = userInput(" [  Access Code ] : ");
		return accessInfo;

	}

	private String Step2(String title, String data) {
		this.display(title);
		this.display(data.split(":")[0]);
		this.display("\n 1. 예약 대기 " + data.split(":")[1] +  "2. 금일 예약 " + data.split(":")[2]);
		return userInput("\n___________________________________________ Select :");
	}

	private String [][] Step3(String title, String data) {
		String storeData = " 1:01056808050:2021-05-11:5";
		String store [] = null;
		String stores [][] = null;

		store = storeData.split(":");
		/* 0   1   2    3
		 * 1
		 * 01056808050
		 * 2021-05-11
		 * 5 */
		stores = new String [store.length][1];
		for (int index =0; index < store.length; index ++) {
			stores [index][0] = store [index];
		}

		this.display(title);
		this.display(data.split(":")[0]);
		this.display("  -----------------------------------------------------------\n");
		this.display("       순번          예약자 번호        예약일자       주문건수          ");
		this.display("  -----------------------------------------------------------\n");
		this.display ("   " + stores[0][0] +"\t" + stores[1][0]+ "\t"+ stores[2][0] + "\t" + stores[3][0]);
		return stores;

	}
	;


	private String setTitle() {
		StringBuffer sb = new StringBuffer();

		sb.append("\n\n\n+++++++++++++++++++++++++++++++++++++++\n");
		sb.append("      Reservation System for Store      \n");
		sb.append("+++++++++++++++++++++++++++++++++++++++\n");
		return sb.toString();



	}

	private String userInput(String item) {
		this.display(item);

		return scanner.next();

	}

	private void display(String text) {
		System.out.print(text);
	}

}