package view;

import java.util.Scanner;

import controller.FrontController;

public class View1 {
	Scanner scanner;
	FrontController fc;

	public View1() {
		scanner = new Scanner(System.in);
		fc = new FrontController();
		this.entrance();
	}

	private void entrance() {
		String title = this.setTitle();
		String[] accessInfo;
		String response;
		
		// 濡쒓렇�씤 �꽦怨� �뿬遺��뿉 �뵲瑜� S001 諛섎났
		while(true) {
			/* S001 */
			while(true) {
				accessInfo =this.s001(title);
				if(this.userInput(" __________________________________Confirm(y/n) : ").equals("y")) {
					break;
				}
			}
			/* Server�뿉 �뜲�씠�꽣 �슂泥� */
			response = fc.entrance(1, accessInfo);
			
			if(Integer.parseInt(response.split(":")[1]) != -1 ) {
				break;
			}
		}
		
		
		/*S002*/
		int serviceCode = -1;
		while(true) {
			int selection = this.s002(title, response);
			if(selection == 1) {serviceCode=2; break;}
			if(selection == 2) {serviceCode=3; break;}
		}

		
		/* �꽌踰꾩뿉�꽌 �쟾�떖�맂 �뜲�씠�꽣 */
		String serverData = fc.entrance(serviceCode, accessInfo) ;
		// String --> String[][]
		String[][] data = this.convertType(serverData);
		
		/* S003 */
		StringBuffer sb = new StringBuffer();
		
		while(true) {
			sb.append(this.s003(title, response, data));
			if(this.userInput(" __________________________________ Confirm(y/n) : ").equals("n")) {
				break;
			}else {
				sb.append(",");
			}
		}
		String[] indexes = sb.toString().split(",");
		String[] cData= new String[indexes.length];
		int index = -1;
		for(String sIndex : indexes) {
			index++;
			cData[index] = data[Integer.parseInt(sIndex)-1][0] + "," + data[Integer.parseInt(sIndex)-1][1] + "," + data[Integer.parseInt(sIndex)-1][2];
		}
		
		fc.entrance(4, cData);
		
	}

	private String [][] convertType(String data){
		String[][]list;
		String[] recordData = data.split(":");
		list = new String [recordData.length][];
		for(int record =0; record < recordData.length; record ++) {
			list[record] =recordData[record].split(",");
			}
		return list;
	}
	private String[] s001 (String title) {
		String[] accessInfo = new String[2];
		this.display(title);
		this.display("[ Certification ]________________________________________\n");
		accessInfo[0]= this.userInput("\n[ Store Code ] : ");
		accessInfo[1]= this.userInput("[ Access Code ] : ");

		return accessInfo;
	}
	
	private int s002(String title, String data) {
		this.display(title);
		this.display(" [ " + data.split(":")[0] + " ]________________________________________\n");
		this.display("\n  1.예약 대기 (" + data.split(":")[1] + ")           2. 금일 예약(" + data.split(":")[2] + ")\n");
		return Integer.parseInt(this.userInput("\n ___________________________________________ Select : "));
	}
	
	private String s003(String title, String store, String[][] data) {
		this.display(title);
		this.display(" [ " + store.split(":")[0] + " ]______________________________________\n");
		this.display("  -----------------------------------------------------------\n");
		this.display("   순번  연락처       예약일자      주문수\n");
		this.display("  -----------------------------------------------------------\n");
		
		for (int record=0; record<data.length; record++) {
			
			
				this.display("   " + (record+1) + "\t");
				for(int index=1; index<data[record].length; index++) {
					this.display(data[record][index]);
					if(index < data[record].length-1) {
						this.display("\t");
					}else {
						this.display("\n");
					}
				}
		
			this.display("\n");
		}
		
		
		
		
		return this.userInput("  \n---------------------------------------  Confirm : ");
	}

	private String setTitle() {
		StringBuffer sb = new StringBuffer();

		sb.append("\n\n\n\n+++++++++++++++++++++++++++++++++++++++++++++++++\n");
		sb.append("          Reservation System for Store       \n");
		sb.append("+++++++++++++++++++++++++++++++++++++++++++++++++\n\n");
		return sb.toString();
	}

	private String userInput(String item) {
		this.display(item);
		return scanner.next();
	}
	private void display(String text) {
		System.out.print(text);
	}
}